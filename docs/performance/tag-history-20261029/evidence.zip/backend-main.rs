#![allow(dead_code, unused_imports)]
mod db; mod automation; mod pipeline; mod storage; mod fsx;
use db::*;
use serde_json::json;
use std::time::Instant;
fn explicit(ids: &[i64])->RowSelection { RowSelection::Explicit{row_ids:ids.to_vec()} }
fn names(values:&[&str])->Vec<String> { values.iter().map(|s|s.to_string()).collect() }
fn emit(stage:&str,t:Instant,extra:serde_json::Value) {
    let s=std::fs::read_to_string("/proc/self/status").unwrap_or_default();
    println!("{}",json!({"stage":stage,"ms":t.elapsed().as_secs_f64()*1000.0,"hwm":s.lines().find(|s|s.starts_with("VmHWM:")),"extra":extra}));
}
fn main()->Result<(),Box<dyn std::error::Error>> {
    let count=std::env::args().nth(1).unwrap_or("10000".into()).parse::<i64>()?;
    let mut d=Database::open_in_memory()?;
    for offset in (0..count).step_by(500) {
        let rows:Vec<_>=(offset+1..=(offset+500).min(count)).map(|i|NewRow{source_ordinal:i as u32,identity:format!("fixture-{i}"),positive_prompt:Some("short prompt".into()),..Default::default()}).collect();
        d.append_batch(SourceType::Folder,"/synthetic",&rows, |_|Ok(()))?;
    }
    let t=Instant::now();
    d.add_tags_to_rows(&[1],&names(&["A","R"]))?;
    d.add_tags_to_rows(&[2],&names(&["R"]))?;
    let edit=d.edit_selection_tags(&explicit(&[1,2,2]),&names(&[" A ","A","a"]),&names(&["R"]))?;
    assert_eq!(edit.affected_rows,2);
    assert_eq!(edit.changes.added[0].row_ids,vec![2]);
    d.add_tags_to_rows(&[1],&names(&["unrelated"]))?; d.update_note(1,"keep this note")?;
    let group=d.create_group("keep group")?;
    d.lab_sql(&format!("UPDATE rows SET group_id={} WHERE id=1",group.id));
    d.apply_tag_changes(&edit.changes,true)?;
    let rows=d.get_rows_by_ids(&[1,2])?;
    assert_eq!(rows[0].tags,names(&["A","R","unrelated"]));
    assert_eq!(rows[1].tags,names(&["R"]));
    assert_eq!(rows[0].note.as_deref(),Some("keep this note")); assert_eq!(rows[0].group_id,Some(group.id));
    d.apply_tag_changes(&edit.changes,false)?;
    assert_eq!(d.get_rows_by_ids(&[2])?[0].tags,names(&["A","a"]));
    let noop=d.edit_selection_tags(&explicit(&[1,2]),&names(&["A"]),&names(&["absent"]))?;
    assert!(noop.changes.added.is_empty() && noop.changes.removed.is_empty());
    // A constraint failure after the first requested insert must undo the entire edit.
    d.lab_sql("CREATE TEMP TRIGGER lab_fail BEFORE INSERT ON row_tags WHEN (SELECT name FROM tags WHERE id=NEW.tag_id)='fail' BEGIN SELECT RAISE(ABORT,'injected failure'); END;");
    assert!(d.edit_selection_tags(&explicit(&[1,2]),&names(&["partial","fail"]),&names(&["A"])).is_err());
    assert!(!d.list_tags()?.iter().any(|x| x.name=="partial"));
    assert!(d.get_rows_by_ids(&[1])?[0].tags.contains(&"A".into()));
    d.lab_sql("DROP TRIGGER lab_fail;");
    // Unknown row in the second delta must roll back the first delta too.
    let invalid=TagChanges{added:vec![TagAssociationChange{tag:"A".into(),row_ids:vec![1]},TagAssociationChange{tag:"A".into(),row_ids:vec![count+1]}],removed:vec![]};
    assert!(d.apply_tag_changes(&invalid,true).is_err());
    assert!(d.get_rows_by_ids(&[1])?[0].tags.contains(&"A".into()));
    let filter:RowSelection=serde_json::from_value(json!({"kind":"filtered","tags":["A"],"tagMode":"and","dedupe":"none","search":"","excludedRowIds":[2]}))?;
    let filtered=d.edit_selection_tags(&filter,&names(&["frozen"]),&names(&["A"]))?;
    assert_eq!(filtered.affected_rows,1); assert_eq!(filtered.changes.removed[0].row_ids,vec![1]);
    d.apply_tag_changes(&filtered.changes,true)?;
    emit("correctness",t,json!({"passed":true,"cases":["delta","undo-redo","unrelated-data","noop","transaction-failure","missing-row-rollback","filtered-selection"]}));
    let ids:Vec<_>=(1..=count).collect(); let mut history=Vec::new();
    for round in 1..=3 {
        let t=Instant::now();
        let r=d.edit_selection_tags(&explicit(&ids),&vec![format!("bulk-{round}")],&[])?;
        assert_eq!(r.changes.added[0].row_ids.len(),count as usize);
        emit("bulk_delta",t,json!({"count":count,"round":round,"jsonBytes":serde_json::to_vec(&r)?.len()}));
        history.push(r.changes);
    }
    let t=Instant::now();
    for changes in history.iter().rev() { assert_eq!(d.apply_tag_changes(changes,true)?,count as usize); }
    for changes in &history { assert_eq!(d.apply_tag_changes(changes,false)?,count as usize); }
    emit("bulk_undo_redo",t,json!({"passed":true,"count":count}));
    Ok(())
}

