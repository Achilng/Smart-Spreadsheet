from pathlib import Path
import shutil
root=Path('D:/Agent/智能表格')
base=Path('D:/Agent/Agent_temp/memory-lab-20261029')
lab=Path('D:/Agent/Agent_temp/memory-optimize-20261029')
shutil.copytree(base/'backend',lab/'backend',dirs_exist_ok=True)
for folder in ['db','automation']:
    for f in (root/'src-tauri/src'/folder).rglob('*.rs'):
        shutil.copy2(f,lab/'backend/src'/f.relative_to(root/'src-tauri/src'))
with (lab/'backend/src/db/mod.rs').open('a',encoding='utf-8') as f:
    f.write('\nimpl Database { pub fn lab_sql(&self, sql: &str) { self.connection.execute_batch(sql).unwrap(); } }\n')
shutil.copy2(lab/'backend-main.rs',lab/'backend/src/main.rs')
(lab/'results').mkdir(exist_ok=True)
(lab/'tmp').mkdir(exist_ok=True)
