import {performance,monitorEventLoopDelay} from 'node:perf_hooks';
import * as h from './history-final.mjs';
import {tags} from './adapter.mjs';
const count=Number(process.argv[2]);
const ids=Array.from({length:count},(_,i)=>i+1);
const hist=monitorEventLoopDelay({resolution:10});hist.enable();
const emit=(stage,t,extra={})=>console.log(JSON.stringify({stage,count,ms:performance.now()-t,memory:process.memoryUsage(),maxRssKiB:process.resourceUsage().maxRSS,eventLoopMaxMs:hist.max/1e6,...extra}));
for(let round=1;round<=3;round++) {
  const t=performance.now();
  for(const id of ids) tags.set(id,[...(tags.get(id)??[]),`tag-${round}`]);
  // Parse the actual backend IPC shape, then pass it to the production history code.
  const result=JSON.parse(JSON.stringify({affectedRows:count,changes:{added:[{tag:`tag-${round}`,rowIds:ids}],removed:[]}}));
  if(!h.recordTagChange(result.changes)) throw Error('history missing');
  await h.refreshTagChanges(result.changes);
  await new Promise(r=>setTimeout(r,30));
  emit('history_retained',t,{round,undoCount:h.useHistory.getState().undoCount});hist.reset();
}
const t=performance.now();
for(let n=0;n<3;n++) await h.undoLastAction();
if(ids.some(id=>tags.get(id).length)) throw Error('undo mismatch');
for(let n=0;n<3;n++) await h.redoLastAction();
if(ids.some(id=>tags.get(id).length!==3)) throw Error('redo mismatch');
const before=h.useHistory.getState().undoCount;
if(h.recordTagChange({added:[],removed:[]})||h.useHistory.getState().undoCount!==before) throw Error('noop history');
await new Promise(r=>setTimeout(r,30));emit('undo_redo_verified',t,{verified:true});hist.disable();h.clearHistory();
