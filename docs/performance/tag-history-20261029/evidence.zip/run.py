from pathlib import Path
import importlib.util
lab=Path('D:/Agent/Agent_temp/memory-optimize-20261029')
spec=importlib.util.spec_from_file_location('runner','D:/Agent/Agent_temp/memory-lab-20261029/run-lab.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);r.lab=lab
for count in [10000,70000]:
    for repeat in [1,2]:
        r.run(f'final_{count}_256_r{repeat}',256,256,'vinlic/doubao-free-api:latest',['node','--max-old-space-size=192','/lab/final-bench.mjs',str(count)])
