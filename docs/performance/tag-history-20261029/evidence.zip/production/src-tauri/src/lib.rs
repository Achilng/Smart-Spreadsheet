mod app;
pub mod automation;
mod images;

pub mod db;
pub mod fsx;
pub mod pipeline;
pub mod storage;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_drag::init())
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_updater::Builder::new().build())
        .setup(|app| {
            use tauri::Manager;

            let locator_path = app.path().app_config_dir()?.join("state.json");
            let default_data_dir = app.path().app_local_data_dir()?.join("data");
            // A development fixture must never open or migrate the installed library.
            #[cfg(debug_assertions)]
            let (locator_path, default_data_dir) = match std::env::var_os("SMART_SPREADSHEET_DEV_DATA") {
                Some(root) => {
                    let root = std::path::PathBuf::from(root);
                    (root.join("state.json"), root.join("library"))
                }
                None => (locator_path, default_data_dir),
            };
            app.manage(app::AppRuntime::load(locator_path, default_data_dir));
            app.manage(app::llm::Engine::default());
            app::llm::start(app.handle().clone());
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            app::commands::llm::llm_snapshot,
            app::commands::llm::llm_save_settings,
            app::commands::llm::refresh_artist_matching,
            app::commands::llm::llm_estimate,
            app::commands::llm::llm_create,
            app::commands::llm::llm_action,
            app::commands::llm::llm_items,
            app::commands::llm::llm_models,
            app::commands::llm::llm_export,
            app::commands::web_tools::open_style_web_tool,
            app::commands::style_extraction::export_style_request,
            app::commands::style_extraction::preview_style_result,
            app::commands::style_extraction::apply_style_changes,
            app::commands::windows::open_toolbox_window,
            app::commands::windows::open_compare_window,
            app::commands::windows::focus_main_window,
            app::commands::library::get_app_snapshot,
            app::commands::library::reset_configuration,
            app::commands::library::reset_data,
            app::commands::library::initialize_data_directory,
            app::commands::library::open_data_directory,
            app::commands::library::set_rejected_images_directory,
            app::commands::library::set_auto_artist_prefix_on_import,
            app::commands::imports::import_images,
            app::commands::imports::update_existing_images,
            app::commands::imports::delete_rows,
            app::commands::imports::undo_import_batch,
            app::commands::editing::restore_mutable_row_states,
            app::commands::imports::list_import_batches,
            app::commands::groups::create_group,
            app::commands::groups::restore_group,
            app::commands::groups::rename_group,
            app::commands::groups::delete_group,
            app::commands::groups::delete_empty_groups,
            app::commands::groups::list_groups,
            app::commands::groups::assign_rows_to_group,
            app::commands::groups::ungroup_rows,
            app::commands::groups::get_group_members,
            app::commands::duplicates::list_dedupe_clusters,
            app::commands::duplicates::get_dedupe_cluster_members,
            app::commands::duplicates::set_dedupe_alias,
            app::commands::artists::list_distinct_artists,
            app::commands::artists::row_ids_with_artists,
            app::commands::artists::get_custom_artists,
            app::commands::artists::set_custom_artists,
            app::commands::prompt_docs::list_prompt_docs,
            app::materials::list_materials,
            app::materials::material_tag_counts,
            app::materials::material_ids_for_tag,
            app::materials::restore_material_tag,
            app::materials::inspect_material_image,
            app::materials::inspect_material_library_image,
            app::materials::save_material,
            app::materials::delete_material,
            app::materials::material_image,
            app::materials::material_version_image,
            app::commands::prompt_docs::create_prompt_doc,
            app::commands::prompt_docs::load_prompt_doc,
            app::commands::prompt_docs::save_prompt_doc,
            app::commands::prompt_docs::delete_prompt_doc,
            app::commands::prompt_docs::import_prompt_doc_image_from_path,
            app::commands::prompt_docs::import_prompt_doc_image_bytes,
            app::commands::editing::update_positive_prompt,
            app::commands::editing::update_character_prompt,
            app::commands::editing::update_negative_prompt,
            app::commands::editing::update_note,
            app::commands::editing::set_favorite,
            app::commands::editing::set_artist_representative,
            app::commands::editing::find_replace_prompt,
            app::commands::editing::prepend_artist,
            app::commands::rows::query_rows,
            app::commands::rows::get_rows_by_ids,
            app::commands::rows::get_row_index,
            app::commands::tags::list_tags,
            app::commands::tags::create_tag,
            app::commands::tags::delete_tag,
            app::commands::tags::rename_tag,
            app::commands::tags::get_recent_tags,
            app::commands::tags::set_recent_tags,
            app::commands::exports::get_image_export_settings,
            app::commands::exports::set_image_export_settings,
            app::commands::rows::count_selected_rows,
            app::commands::tags::list_selection_tags,
            app::commands::rows::selected_row_ids,
            app::commands::tags::add_tags_to_selection,
            app::commands::tags::edit_selection_tags,
            app::commands::tags::apply_tag_changes,
            app::commands::tags::remove_tags_from_selection,
            app::commands::tags::set_tags_for_row,
            app::commands::automation::list_automation_rules,
            app::commands::automation::inspect_automation_rule_file,
            app::commands::automation::import_automation_rule_file,
            app::commands::automation::inspect_automation_rule_text,
            app::commands::automation::import_automation_rule_text,
            app::commands::automation::export_automation_rules,
            app::commands::automation::create_automation_rule,
            app::commands::automation::update_automation_rule,
            app::commands::automation::set_automation_rule_enabled,
            app::commands::automation::delete_automation_rule,
            app::commands::automation::reorder_automation_rules,
            app::commands::automation::preview_automation_rule,
            app::commands::automation::preview_automation_rule_draft,
            app::commands::automation::run_automation_rule_on_library,
            app::commands::imports::cancel_current_task,
            app::commands::quick_edit::preview_quick_tag,
            app::commands::quick_edit::apply_quick_tag,
            app::commands::quick_edit::revert_quick_tag_changes,
            app::commands::quick_edit::reapply_quick_tag_changes,
            app::commands::quick_edit::preview_quick_group,
            app::commands::quick_edit::apply_quick_group,
            app::commands::quick_edit::revert_quick_group_changes,
            app::commands::quick_edit::reapply_quick_group_changes,
            app::commands::quick_edit::preview_quick_artist_prefix,
            app::commands::quick_edit::apply_quick_artist_prefix,
            app::commands::quick_edit::revert_quick_artist_prefix_changes,
            app::commands::quick_edit::reapply_quick_artist_prefix_changes,
            app::commands::quick_edit::preview_auto_artist_prefix,
            app::commands::quick_edit::prefix_confirmed_artists_in_text,
            app::commands::quick_edit::apply_auto_artist_prefix,
            app::commands::images::get_row_thumbnail,
            app::commands::images::get_row_gallery_preview,
            app::commands::images::get_row_preview,
            app::commands::images::get_row_original,
            app::commands::exports::export_row_image,
            app::commands::exports::export_xlsx,
            app::commands::exports::inspect_zhihuiji_export_notes,
            app::commands::exports::export_zhihuiji_json,
            app::commands::exports::export_prompt_rotation_json,
            app::commands::exports::export_image_files,
            app::commands::exports::export_selected_images,
            app::commands::exports::collect_export_images,
            app::commands::exports::inspect_zhihuiji_json,
            app::commands::exports::dedupe_zhihuiji_json,
            app::commands::library::migrate_data_directory,
            app::commands::maintenance::backfill_perceptual_hashes,
            app::commands::maintenance::backfill_vibe_statuses,
            app::commands::maintenance::backfill_style_signatures,
            app::commands::compare::get_compare_sample,
            app::commands::compare::query_compare_same_artists,
            app::commands::compare::query_compare_same_vibe_diff_style,
            app::commands::compare::query_compare_same_style_diff_vibe,
            app::commands::compare::query_compare_same_style_all_models,
            app::commands::images::search_similar_images,
            app::commands::files::show_item_in_explorer,
            app::commands::files::get_row_file_path,
            app::commands::files::open_rejected_images_directory,
            app::commands::files::prepare_file_drag,
            app::commands::images::get_row_vibe_status,
        ])
        .run(tauri::generate_context!())
        .expect("error while running Smart Spreadsheet");
}
