const fs=require('node:fs');
const ts=require('D:/Agent/智能表格/node_modules/typescript');
const root='D:/Agent/智能表格';
const lab='D:/Agent/Agent_temp/memory-optimize-20261029';
const base='D:/Agent/Agent_temp/memory-lab-20261029';
const history=fs.readFileSync(root+'/src/react/state/history.ts','utf8').replace(/^import .*;\r?\n/gm,'');
const rows=fs.readFileSync(root+'/src/lib/api/rows.ts','utf8');
const mutable=rows.slice(rows.indexOf('export function mutableRowState('),rows.indexOf('export interface RowPage'));
const prefix=`import {create,getRowsByIds,restoreMutableRowStates,selectedRowIds,afterLibraryMutation,notify,runTask,useTasks,errorText,registerHistoryClearer,applyTagChanges} from './adapter.mjs';\n`;
fs.writeFileSync(lab+'/history-final.mjs',ts.transpileModule(prefix+mutable+history,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
fs.copyFileSync(base+'/history-baseline.mjs',lab+'/history-baseline.mjs');
fs.copyFileSync(base+'/history-bench.mjs',lab+'/history-bench.mjs');
fs.writeFileSync(lab+'/adapter.mjs',fs.readFileSync(base+'/adapter.mjs','utf8')+`
export async function applyTagChanges(changes,reverse) {
  await new Promise(r=>setImmediate(r));
  for(const c of reverse?changes.added:changes.removed) for(const id of c.rowIds) tags.set(id,(tags.get(id)??[]).filter(t=>t!==c.tag));
  for(const c of reverse?changes.removed:changes.added) for(const id of c.rowIds) if(!(tags.get(id)??[]).includes(c.tag)) tags.set(id,[...(tags.get(id)??[]),c.tag]);
}
`);
