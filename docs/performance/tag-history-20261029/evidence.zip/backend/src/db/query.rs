use std::collections::HashMap;

use rusqlite::types::Value;
use rusqlite::{Connection, params, params_from_iter};
use serde::{Deserialize, Serialize};

use super::library_filters::{LibraryFilter, append_library_filters};
use super::tags::normalize_tags;
use super::search::{SEARCH_COLUMNS, is_search_separator, normalize_search, prepare_search_text};
#[cfg(test)]
use super::search::SEARCH_SEPARATORS;
use super::{Database, DatabaseError};

pub const MAX_PAGE_SIZE: u32 = 500;
pub(super) const FILTER_TAGS_TABLE: &str = "temp.query_filter_tags";
/// 主查询的筛选结果缓存表：随 `Database::query_cache` 一起跨调用复用。
const FILTERED_ROWS_TABLE: &str = "temp.query_filtered_rows";
/// 分组成员等一次性查询的物化表，与缓存表分开以免破坏缓存。
const SCRATCH_ROWS_TABLE: &str = "temp.query_scratch_rows";
pub(super) const PAGE_ROWS_TABLE: &str = "temp.query_page_rows";

/// 已物化筛选结果的标识。key 覆盖全部筛选参数；数据变更通过
/// `Database::bump_data_version` 直接清空缓存。
#[derive(Debug)]
pub(super) struct QueryCache {
    key: String,
    total_count: u64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum TagMatchMode {
    And,
    Or,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum DedupeMode {
    #[default]
    None,
    PositivePrompt,
    Artists,
    Vibes,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum SortMode {
    #[default]
    TimeAsc,
    TimeDesc,
    RecentlyUpdated,
}

#[derive(Debug, Clone, PartialEq, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RowQuery {
    pub offset: u64,
    pub limit: u32,
    pub tags: Vec<String>,
    pub tag_mode: TagMatchMode,
    pub dedupe: DedupeMode,
    #[serde(default)]
    pub single_artist_only: bool,
    #[serde(default)]
    pub artist_filter: String,
    #[serde(default)]
    pub has_vibe: bool,
    #[serde(default)]
    pub untagged_only: bool,
    #[serde(default)]
    pub filters: Vec<LibraryFilter>,
    #[serde(default)]
    pub group_view: bool,
    #[serde(default)]
    pub hide_grouped: bool,
    #[serde(default)]
    pub search: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RowRecord {
    pub id: i64,
    pub favorite: bool,
    pub artist_representative: bool,
    pub batch_id: i64,
    pub source_ordinal: u32,
    pub time: Option<String>,
    pub positive_prompt: Option<String>,
    pub character_prompt: Option<String>,
    pub negative_prompt: Option<String>,
    pub note: Option<String>,
    pub artists: Option<String>,
    pub artist_llm: Option<String>,
    pub image_folder: Option<String>,
    pub image_path: Option<String>,
    pub stored_image_path: Option<String>,
    pub image_width: Option<i64>,
    pub image_height: Option<i64>,
    pub generation_model: Option<String>,
    pub generation_sampler: Option<String>,
    pub generation_steps: Option<u32>,
    pub generation_seed: Option<String>,
    /// CFG scale；REAL 列在此格式化为文本以保持结构体 Eq
    pub generation_scale: Option<String>,
    /// CFG Rescale；同样格式化为文本
    pub generation_cfg_rescale: Option<String>,
    pub generation_noise_schedule: Option<String>,
    pub metadata_failed: bool,
    pub vibe_reference_count: Option<u32>,
    pub group_id: Option<i64>,
    pub group_name: Option<String>,
    pub tags: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RowPage {
    pub rows: Vec<RowRecord>,
    pub total_count: u64,
    pub offset: u64,
    pub limit: u32,
}

impl RowPage {
    pub fn has_more(&self) -> bool {
        self.offset.saturating_add(self.rows.len() as u64) < self.total_count
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TagSummary {
    pub name: String,
    pub row_count: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DedupeCluster {
    pub key: String,
    pub member_count: u64,
    pub alias: Option<String>,
}

impl Database {
    pub fn query_rows(&mut self, query: &RowQuery) -> Result<RowPage, DatabaseError> {
        self.query_rows_sorted(query, SortMode::TimeAsc)
    }

    pub fn query_rows_sorted(
        &mut self,
        query: &RowQuery,
        sort: SortMode,
    ) -> Result<RowPage, DatabaseError> {
        if query.limit == 0 || query.limit > MAX_PAGE_SIZE {
            return Err(DatabaseError::InvalidPageSize {
                requested: query.limit,
                maximum: MAX_PAGE_SIZE,
            });
        }
        let offset = i64::try_from(query.offset).map_err(|_| DatabaseError::OffsetOverflow)?;
        let tags = normalize_tags(&query.tags);
        let cache_key = query_cache_key(query, &tags);
        let cached_total = self
            .query_cache
            .as_ref()
            .filter(|cache| cache.key == cache_key)
            .map(|cache| cache.total_count);

        let total_count = match cached_total {
            Some(total) => total,
            None => {
                self.query_cache = None;
                let transaction = self.connection.transaction()?;
                create_filter_tags(&transaction, &tags)?;
                create_filtered_rows_table(&transaction, FILTERED_ROWS_TABLE)?;
                populate_filtered_rows(
                    &transaction,
                    FILTERED_ROWS_TABLE,
                    query.tag_mode,
                    query.dedupe,
                    query.single_artist_only,
                    &query.artist_filter,
                    query.has_vibe,
                    query.untagged_only,
                    &query.filters,
                    query.group_view,
                    query.hide_grouped,
                    &query.search,
                )?;
                transaction.execute_batch(&format!("DROP TABLE {FILTER_TAGS_TABLE};"))?;
                transaction.commit()?;
                let total = query_total_count(&self.connection, FILTERED_ROWS_TABLE)?;
                self.query_cache = Some(QueryCache {
                    key: cache_key,
                    total_count: total,
                });
                total
            }
        };

        create_page_rows_table(&self.connection)?;
        create_page_rows(
            &self.connection,
            FILTERED_ROWS_TABLE,
            query.limit,
            offset,
            sort,
        )?;
        let mut rows = query_page_metadata(&self.connection)?;
        attach_page_tags(&self.connection, &mut rows)?;
        self.connection
            .execute_batch(&format!("DROP TABLE {PAGE_ROWS_TABLE};"))?;

        Ok(RowPage {
            rows,
            total_count,
            offset: query.offset,
            limit: query.limit,
        })
    }

    pub fn get_rows_by_ids(&mut self, ids: &[i64]) -> Result<Vec<RowRecord>, DatabaseError> {
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        let transaction = self.connection.transaction()?;
        transaction.execute_batch(&format!(
            "DROP TABLE IF EXISTS {PAGE_ROWS_TABLE};
             CREATE TEMP TABLE {PAGE_ROWS_TABLE} (
                 ordinal INTEGER PRIMARY KEY,
                 id INTEGER NOT NULL UNIQUE
             ) STRICT;"
        ))?;
        let mut insert =
            transaction.prepare(&format!("INSERT OR IGNORE INTO {PAGE_ROWS_TABLE}(ordinal, id) VALUES (?1, ?2)"))?;
        for (index, id) in ids.iter().enumerate() {
            insert.execute(rusqlite::params![index as i64, *id])?;
        }
        drop(insert);
        let mut rows = query_page_metadata(&transaction)?;
        attach_page_tags(&transaction, &mut rows)?;
        transaction.execute_batch(&format!("DROP TABLE {PAGE_ROWS_TABLE};"))?;
        transaction.commit()?;
        Ok(rows)
    }

    /// 返回未筛选资料库中指定行的零基序号。默认沿用历史的导入正序。
    pub fn row_index_by_id(&self, row_id: i64) -> Result<u64, DatabaseError> {
        self.row_index_by_id_sorted(row_id, SortMode::TimeAsc)
    }

    pub fn row_index_by_id_sorted(
        &self,
        row_id: i64,
        sort: SortMode,
    ) -> Result<u64, DatabaseError> {
        let exists: bool = self.connection.query_row(
            "SELECT EXISTS(SELECT 1 FROM rows WHERE id = ?1)",
            [row_id],
            |row| row.get(0),
        )?;
        if !exists {
            return Err(DatabaseError::RowNotFound(row_id));
        }
        let order_by = sort_order_sql(sort, "rows");
        let index: i64 = self.connection.query_row(
            &format!(
                "SELECT ordinal - 1
                 FROM (
                     SELECT rows.id, ROW_NUMBER() OVER (ORDER BY {order_by}) AS ordinal
                     FROM rows
                 )
                 WHERE id = ?1"
            ),
            [row_id],
            |row| row.get(0),
        )?;
        u64::try_from(index).map_err(|_| DatabaseError::CountOverflow)
    }

    pub fn get_group_members(
        &mut self,
        group_id: i64,
        offset: u64,
        limit: u32,
        sort: SortMode,
    ) -> Result<RowPage, DatabaseError> {
        if limit == 0 || limit > MAX_PAGE_SIZE {
            return Err(DatabaseError::InvalidPageSize {
                requested: limit,
                maximum: MAX_PAGE_SIZE,
            });
        }
        let offset_i64 = i64::try_from(offset).map_err(|_| DatabaseError::OffsetOverflow)?;
        let transaction = self.connection.transaction()?;
        create_filtered_rows_table(&transaction, SCRATCH_ROWS_TABLE)?;
        transaction.execute(
            &format!(
                "INSERT INTO {SCRATCH_ROWS_TABLE}(id)
                 SELECT id FROM rows WHERE group_id = ?1"
            ),
            [group_id],
        )?;
        create_page_rows_table(&transaction)?;
        create_page_rows(
            &transaction,
            SCRATCH_ROWS_TABLE,
            limit,
            offset_i64,
            sort,
        )?;

        let total_count = query_total_count(&transaction, SCRATCH_ROWS_TABLE)?;
        let mut rows = query_page_metadata(&transaction)?;
        attach_page_tags(&transaction, &mut rows)?;

        transaction.execute_batch(&format!(
            "DROP TABLE {PAGE_ROWS_TABLE};
             DROP TABLE {SCRATCH_ROWS_TABLE};"
        ))?;
        transaction.commit()?;

        Ok(RowPage {
            rows,
            total_count,
            offset,
            limit,
        })
    }

    pub fn list_tags(&self) -> Result<Vec<TagSummary>, DatabaseError> {
        let mut statement = self.connection.prepare(
            "SELECT tags.name, COUNT(row_tags.row_id)
             FROM tags
             LEFT JOIN row_tags ON row_tags.tag_id = tags.id
             GROUP BY tags.id, tags.name
             ORDER BY tags.name COLLATE BINARY",
        )?;
        let stored = statement
            .query_map([], |row| {
                Ok((row.get::<_, String>(0)?, row.get::<_, i64>(1)?))
            })?
            .collect::<Result<Vec<_>, _>>()?;
        let summaries = stored
            .into_iter()
            .map(|(name, row_count)| {
                Ok(TagSummary {
                    name,
                    row_count: u64::try_from(row_count)
                        .map_err(|_| DatabaseError::CountOverflow)?,
                })
            })
            .collect::<Result<Vec<_>, DatabaseError>>()?;
        Ok(summaries)
    }

    /// LLM 结果按逗号/换行拆分并补全各片段权重；其它来源保留原有换行片段。
    /// 仅构造随机画师池，不改写已保存的画师串和 LLM 来源。
    pub fn list_distinct_artists(&self) -> Result<Vec<String>, DatabaseError> {
        let mut statement = self.connection.prepare(
            "SELECT artists, artist_llm IS NOT NULL FROM rows
             WHERE artists IS NOT NULL AND TRIM(artists) != ''",
        )?;
        let stored = statement
            .query_map([], |row| Ok((row.get::<_, String>(0)?, row.get::<_, bool>(1)?)))?
            .collect::<Result<Vec<_>, _>>()?;
        let mut set = std::collections::BTreeSet::new();
        for (value, is_llm) in stored {
            if is_llm {
                set.extend(crate::pipeline::llm_artist_pool_fragments(&value));
                continue;
            }
            for fragment in value.split('\n') {
                let trimmed = fragment.trim();
                if !trimmed.is_empty() {
                    set.insert(trimmed.to_string());
                }
            }
        }
        Ok(set.into_iter().collect())
    }

    /// 返回共享画风匹配标识相同的所有行 ID（全库，忽略 Tag 筛选）。
    pub fn row_ids_with_artists(&self, artists: &str) -> Result<Vec<i64>, DatabaseError> {
        let Some(key) = self.artist_key(artists)? else {
            return Ok(Vec::new());
        };
        let mut statement = self.connection.prepare(
            "SELECT id FROM rows
             WHERE artist_match_key = ?1
             ORDER BY id",
        )?;
        let ids = statement
            .query_map(params![key], |row| row.get::<_, i64>(0))?
            .collect::<Result<Vec<_>, _>>()?;
        Ok(ids)
    }

    #[allow(clippy::too_many_arguments)]
    pub fn list_dedupe_clusters(
        &mut self,
        dedupe: DedupeMode,
        tags: &[String],
        tag_mode: TagMatchMode,
        single_artist_only: bool,
        has_vibe: bool,
        untagged_only: bool,
        filters: &[LibraryFilter],
        hide_grouped: bool,
    ) -> Result<Vec<DedupeCluster>, DatabaseError> {
        let Some((key_expression, mode_str)) = dedupe_identity(dedupe) else {
            return Ok(Vec::new());
        };
        let normalized = normalize_tags(tags);
        let transaction = self.connection.transaction()?;
        create_filter_tags(&transaction, &normalized)?;

        let tag_predicate = filter_predicate(tag_mode);
        let mut predicate = tag_predicate.to_owned();
        if single_artist_only {
            predicate = format!(
                "({predicate})
                 AND rows.artists IS NOT NULL
                 AND TRIM(rows.artists) != ''
                 AND INSTR(rows.artists, CHAR(10)) = 0
                 AND INSTR(rows.artists, ',') = 0"
            );
        }
        if has_vibe {
            predicate = format!("({predicate}) AND rows.vibe_reference_count > 0");
        }
        if untagged_only {
            predicate = format!(
                "({predicate}) AND NOT EXISTS (SELECT 1 FROM row_tags WHERE row_tags.row_id = rows.id)"
            );
        }
        if hide_grouped {
            predicate = format!("({predicate}) AND rows.group_id IS NULL");
        }
        let mut filter_params = Vec::new();
        predicate = append_library_filters(predicate, filters, &mut filter_params);
        filter_params.push(Value::Text(mode_str.to_owned()));
        let mode_parameter = filter_params.len();

        let clusters = {
            let mut statement = transaction.prepare(&format!(
                "SELECT g.dedupe_key, g.cnt, NULLIF(da.alias, '')
                 FROM (
                     SELECT dedupe_key, COUNT(*) AS cnt
                     FROM (
                         SELECT {key_expression} AS dedupe_key
                         FROM rows
                         WHERE {predicate}
                     )
                     WHERE dedupe_key IS NOT NULL
                     GROUP BY dedupe_key
                     HAVING cnt >= 2
                 ) g
                 LEFT JOIN dedupe_aliases da ON da.mode = ?{mode_parameter} AND da.key = g.dedupe_key
                 ORDER BY g.cnt DESC, g.dedupe_key"
            ))?;
            statement
                .query_map(params_from_iter(filter_params.iter()), |row| {
                    Ok(DedupeCluster {
                        key: row.get(0)?,
                        member_count: row.get::<_, i64>(1)? as u64,
                        alias: row.get(2)?,
                    })
                })?
                .collect::<Result<Vec<_>, _>>()?
        };

        transaction.execute_batch(&format!("DROP TABLE {FILTER_TAGS_TABLE};"))?;
        transaction.commit()?;
        Ok(clusters)
    }

    #[allow(clippy::too_many_arguments)]
    pub fn get_dedupe_cluster_members(
        &mut self,
        dedupe: DedupeMode,
        key: &str,
        tags: &[String],
        tag_mode: TagMatchMode,
        single_artist_only: bool,
        has_vibe: bool,
        untagged_only: bool,
        filters: &[LibraryFilter],
        hide_grouped: bool,
        offset: u64,
        limit: u32,
        sort: SortMode,
    ) -> Result<RowPage, DatabaseError> {
        if limit == 0 || limit > MAX_PAGE_SIZE {
            return Err(DatabaseError::InvalidPageSize {
                requested: limit,
                maximum: MAX_PAGE_SIZE,
            });
        }
        let Some((key_expression, _)) = dedupe_identity(dedupe) else {
            return Ok(RowPage {
                rows: Vec::new(),
                total_count: 0,
                offset,
                limit,
            });
        };
        let key = if dedupe == DedupeMode::Artists {
            self.artist_key(key)?
        } else {
            Some(key.to_owned())
        };
        let offset_i64 = i64::try_from(offset).map_err(|_| DatabaseError::OffsetOverflow)?;
        let normalized = normalize_tags(tags);
        let transaction = self.connection.transaction()?;
        create_filter_tags(&transaction, &normalized)?;

        let tag_predicate = filter_predicate(tag_mode);
        let mut predicate = tag_predicate.to_owned();
        if single_artist_only {
            predicate = format!(
                "({predicate})
                 AND rows.artists IS NOT NULL
                 AND TRIM(rows.artists) != ''
                 AND INSTR(rows.artists, CHAR(10)) = 0
                 AND INSTR(rows.artists, ',') = 0"
            );
        }
        if has_vibe {
            predicate = format!("({predicate}) AND rows.vibe_reference_count > 0");
        }
        if untagged_only {
            predicate = format!(
                "({predicate}) AND NOT EXISTS (SELECT 1 FROM row_tags WHERE row_tags.row_id = rows.id)"
            );
        }
        if hide_grouped {
            predicate = format!("({predicate}) AND rows.group_id IS NULL");
        }
        let mut filter_params = vec![key.map(Value::Text).unwrap_or(Value::Null)];
        predicate = append_library_filters(predicate, filters, &mut filter_params);

        create_filtered_rows_table(&transaction, SCRATCH_ROWS_TABLE)?;
        transaction.execute(
            &format!(
                "INSERT INTO {SCRATCH_ROWS_TABLE}(id)
                 SELECT rows.id FROM rows
                 WHERE {key_expression} = ?1
                   AND ({predicate})"
            ),
            params_from_iter(filter_params.iter()),
        )?;
        create_page_rows_table(&transaction)?;
        create_page_rows(
            &transaction,
            SCRATCH_ROWS_TABLE,
            limit,
            offset_i64,
            sort,
        )?;

        let total_count = query_total_count(&transaction, SCRATCH_ROWS_TABLE)?;
        let mut rows = query_page_metadata(&transaction)?;
        attach_page_tags(&transaction, &mut rows)?;

        transaction.execute_batch(&format!(
            "DROP TABLE {PAGE_ROWS_TABLE};
             DROP TABLE {SCRATCH_ROWS_TABLE};
             DROP TABLE {FILTER_TAGS_TABLE};"
        ))?;
        transaction.commit()?;

        Ok(RowPage {
            rows,
            total_count,
            offset,
            limit,
        })
    }

    pub fn set_dedupe_alias(
        &mut self,
        mode: DedupeMode,
        key: &str,
        alias: &str,
    ) -> Result<(), DatabaseError> {
        let key = if mode == DedupeMode::Artists {
            self.artist_key(key)?.ok_or(DatabaseError::EmptyArtists)?
        } else {
            key.to_owned()
        };
        let mode_str = match mode {
            DedupeMode::PositivePrompt => "positivePrompt",
            DedupeMode::Artists => "artists",
            DedupeMode::Vibes => "vibes",
            DedupeMode::None => return Ok(()),
        };
        let alias = alias.trim();
        // An empty artist alias is an intentional reset; preserve it so refresh cannot
        // resurrect an older alias retained during a merge.
        if alias.is_empty() && mode != DedupeMode::Artists {
            self.connection.execute(
                "DELETE FROM dedupe_aliases WHERE mode = ?1 AND key = ?2",
                params![mode_str, key],
            )?;
        } else {
            self.connection.execute(
                "INSERT INTO dedupe_aliases (mode, key, alias) VALUES (?1, ?2, ?3)
                 ON CONFLICT(mode, key) DO UPDATE SET alias = excluded.alias",
                params![mode_str, key, alias],
            )?;
        }
        Ok(())
    }
}

/// All duplicate-group and dedupe queries share the same identity column/expression.
fn dedupe_identity(mode: DedupeMode) -> Option<(&'static str, &'static str)> {
    match mode {
        DedupeMode::Artists => Some(("rows.artist_match_key", "artists")),
        DedupeMode::PositivePrompt => Some((
            "NULLIF(TRIM(COALESCE(rows.positive_prompt, '')), '')", "positivePrompt",
        )),
        DedupeMode::Vibes => Some((
            "NULLIF(TRIM(COALESCE(rows.vibe_signature, '')), '')", "vibes",
        )),
        DedupeMode::None => None,
    }
}

/// 缓存键覆盖影响筛选结果集的全部参数（分页参数除外）。
fn query_cache_key(query: &RowQuery, normalized_tags: &[String]) -> String {
    format!(
        "{tags:?}\u{1}{mode:?}\u{1}{dedupe:?}\u{1}{sao}\u{1}{artist}\u{1}{vibe}\u{1}{untagged}\u{1}{filters}\u{1}{gv}\u{1}{hg}\u{1}{search}",
        tags = normalized_tags,
        mode = query.tag_mode,
        dedupe = query.dedupe,
        sao = query.single_artist_only,
        artist = query.artist_filter.trim(),
        vibe = query.has_vibe,
        untagged = query.untagged_only,
        filters = serde_json::to_string(&query.filters).unwrap_or_default(),
        gv = query.group_view,
        hg = query.hide_grouped,
        search = query.search.trim().to_lowercase(),
    )
}

pub(super) fn create_filter_tags(
    connection: &Connection,
    tags: &[String],
) -> Result<(), rusqlite::Error> {
    connection.execute_batch(&format!(
        "DROP TABLE IF EXISTS {FILTER_TAGS_TABLE};
         CREATE TEMP TABLE {FILTER_TAGS_TABLE} (
             name TEXT PRIMARY KEY COLLATE BINARY
         ) STRICT, WITHOUT ROWID;"
    ))?;
    let mut insert = connection.prepare(&format!(
        "INSERT INTO {FILTER_TAGS_TABLE}(name) VALUES (?1)"
    ))?;
    for tag in tags {
        insert.execute([tag])?;
    }
    Ok(())
}

fn create_page_rows_table(connection: &Connection) -> Result<(), rusqlite::Error> {
    connection.execute_batch(&format!(
        "DROP TABLE IF EXISTS {PAGE_ROWS_TABLE};
         CREATE TEMP TABLE {PAGE_ROWS_TABLE} (
             ordinal INTEGER PRIMARY KEY,
             id INTEGER NOT NULL UNIQUE
         ) STRICT;"
    ))
}

fn create_filtered_rows_table(
    connection: &Connection,
    table: &str,
) -> Result<(), rusqlite::Error> {
    connection.execute_batch(&format!(
        "DROP TABLE IF EXISTS {table};
         CREATE TEMP TABLE {table} (
             id INTEGER PRIMARY KEY
         ) STRICT, WITHOUT ROWID;"
    ))
}

#[allow(clippy::too_many_arguments)]
pub(super) fn populate_filtered_rows(
    connection: &Connection,
    target_table: &str,
    mode: TagMatchMode,
    dedupe: DedupeMode,
    single_artist_only: bool,
    artist_filter: &str,
    has_vibe: bool,
    untagged_only: bool,
    filters: &[LibraryFilter],
    group_view: bool,
    hide_grouped: bool,
    search: &str,
) -> Result<(), rusqlite::Error> {
    let tag_predicate = filter_predicate(mode);
    let mut predicate = tag_predicate.to_owned();
    if single_artist_only {
        predicate = format!(
            "({predicate})
             AND rows.artists IS NOT NULL
             AND TRIM(rows.artists) != ''
             AND INSTR(rows.artists, CHAR(10)) = 0
             AND INSTR(rows.artists, ',') = 0"
        );
    }
    let artist_filter = artist_filter.trim().to_owned();
    let mut filter_params: Vec<Value> = Vec::new();
    if !artist_filter.is_empty() {
        let parameter = filter_params.len() + 1;
        predicate = format!(
            "({predicate}) AND rows.artist_match_key = style_match_key(?{parameter}, (SELECT value FROM settings WHERE key='local_llm_settings_v1'))"
        );
        filter_params.push(Value::Text(artist_filter));
    }
    if has_vibe {
        predicate = format!("({predicate}) AND rows.vibe_reference_count > 0");
    }
    if untagged_only {
        // row_tags 主键以 row_id 前导，NOT EXISTS 走主键索引
        predicate = format!(
            "({predicate}) AND NOT EXISTS (SELECT 1 FROM row_tags WHERE row_tags.row_id = rows.id)"
        );
    }
    if !group_view && hide_grouped {
        predicate = format!("({predicate}) AND rows.group_id IS NULL");
    }
    predicate = append_library_filters(predicate, filters, &mut filter_params);

    let search_lower = search.trim().to_lowercase();
    let has_search = !search_lower.is_empty();
    if has_search {
        prepare_search_text(connection)?;
        create_filtered_rows_table(connection, "temp.query_search_matches")?;
        let compact_parameter = filter_params.len() + 1;
        let match_parameter = |parameter| SEARCH_COLUMNS.iter()
            .map(|c| format!("INSTR(search_text.{c}, ?{parameter}) > 0"))
            .collect::<Vec<_>>().join(" OR ");
        let full = match_parameter(compact_parameter);
        let mut tokens: Vec<&str> = search_lower
            .split(is_search_separator)
            .filter(|token| !token.is_empty())
            .collect();
        let can_fallback = tokens.len() > 1;
        tokens.sort_unstable();
        tokens.dedup();
        filter_params.push(Value::Text(normalize_search(search)));
        // Materialize full matches once, before pagination/grouping/dedupe. No
        // EXISTS probe followed by a second full scan (especially costly on misses).
        let insert_matches = |search_predicate: &str, values: &[Value]| connection.execute(
            &format!("INSERT INTO temp.query_search_matches(id)
                SELECT rows.id FROM temp.query_search_text AS search_text
                JOIN rows ON rows.id = search_text.id
                WHERE ({predicate}) AND ({search_predicate})"),
            params_from_iter(values.iter()),
        );
        let full_count = insert_matches(&full, &filter_params)?;
        if full_count == 0 && can_fallback {
            filter_params.pop();
            let mut parts = Vec::new();
            for token in &tokens {
                let parameter = filter_params.len() + 1;
                parts.push(format!("({})", match_parameter(parameter)));
                filter_params.push(Value::Text((*token).to_owned()));
            }
            insert_matches(&parts.join(" AND "), &filter_params)?;
        }
        // All filters are already applied to the materialized IDs.
        predicate = "rows.id IN (SELECT id FROM temp.query_search_matches)".to_owned();
        filter_params.clear();
    }

    if group_view {
        connection.execute(
            &format!(
                "INSERT INTO {target_table}(id)
                 SELECT MIN(rows.id) FROM rows
                 WHERE ({predicate}) AND rows.group_id IS NOT NULL
                 GROUP BY rows.group_id
                 UNION ALL
                 SELECT rows.id FROM rows
                 WHERE ({predicate}) AND rows.group_id IS NULL"
            ),
            params_from_iter(filter_params.iter()),
        )?;
    } else {
        match dedupe {
            DedupeMode::None => connection.execute(
                &format!(
                    "INSERT INTO {target_table}(id)
                     SELECT rows.id FROM rows WHERE {predicate}"
                ),
                params_from_iter(filter_params.iter()),
            )?,
            DedupeMode::PositivePrompt | DedupeMode::Artists | DedupeMode::Vibes => {
                let (key_expression, _) = dedupe_identity(dedupe).expect("dedupe mode checked");
                let representative = if dedupe == DedupeMode::Artists {
                    "CASE WHEN rows.id IN (SELECT row_id FROM artist_representatives) THEN rows.id END"
                } else {
                    "NULL"
                };
                connection.execute(
                    &format!(
                        "INSERT INTO {target_table}(id)
                         WITH filtered_rows AS (
                             SELECT rows.id,
                                    {key_expression} AS dedupe_key,
                                    {representative} AS representative_id
                             FROM rows
                             WHERE {predicate}
                         )
                         SELECT id FROM filtered_rows WHERE dedupe_key IS NULL
                         UNION ALL
                         SELECT COALESCE(MIN(representative_id), MIN(id))
                         FROM filtered_rows
                         WHERE dedupe_key IS NOT NULL
                         GROUP BY dedupe_key"
                    ),
                    params_from_iter(filter_params.iter()),
                )?
            }
        };
    }
    Ok(())
}

fn create_page_rows(
    connection: &Connection,
    source_table: &str,
    limit: u32,
    offset: i64,
    sort: SortMode,
) -> Result<(), rusqlite::Error> {
    let order_by = sort_order_sql(sort, "rows");
    connection.execute(
        &format!(
            "INSERT INTO {PAGE_ROWS_TABLE}(ordinal, id)
             SELECT ROW_NUMBER() OVER (ORDER BY {order_by}), filtered.id
             FROM {source_table} AS filtered
             JOIN rows ON rows.id = filtered.id
             ORDER BY {order_by}
             LIMIT ?1 OFFSET ?2"
        ),
        params![limit, offset],
    )?;
    Ok(())
}

fn sort_order_sql(sort: SortMode, rows_alias: &str) -> String {
    match sort {
        SortMode::TimeAsc => format!("{rows_alias}.id ASC"),
        SortMode::TimeDesc => format!("{rows_alias}.id DESC"),
        SortMode::RecentlyUpdated => format!(
            "COALESCE({rows_alias}.updated_at, '') DESC, {rows_alias}.id DESC"
        ),
    }
}

fn query_total_count(connection: &Connection, table: &str) -> Result<u64, DatabaseError> {
    let count: i64 = connection.query_row(
        &format!("SELECT COUNT(*) FROM {table}"),
        [],
        |row| row.get(0),
    )?;
    u64::try_from(count).map_err(|_| DatabaseError::CountOverflow)
}

/// CFG scale 展示格式：整数值不带小数点，其余保留原精度。
fn format_generation_scale(scale: f64) -> String {
    if scale.fract() == 0.0 {
        format!("{}", scale as i64)
    } else {
        format!("{scale}")
    }
}

pub(super) fn query_page_metadata(connection: &Connection) -> Result<Vec<RowRecord>, DatabaseError> {
    let mut statement = connection.prepare(&format!(
        "SELECT rows.id, rows.batch_id, rows.source_ordinal, rows.time,
                rows.positive_prompt, rows.character_prompt, rows.negative_prompt, rows.note,
                rows.artists, rows.image_folder, rows.image_path, rows.stored_image_path,
                rows.image_width, rows.image_height,
                rows.generation_model, rows.generation_sampler, rows.generation_steps,
                rows.generation_seed, rows.generation_scale,
                rows.generation_cfg_rescale, rows.generation_noise_schedule,
                rows.metadata_failed, rows.vibe_reference_count, rows.group_id, groups.name, rows.artist_llm, rows.favorite,
                rows.id IN (SELECT row_id FROM artist_representatives)
         FROM {PAGE_ROWS_TABLE} AS page
         JOIN rows ON rows.id = page.id
         LEFT JOIN groups ON groups.id = rows.group_id
         ORDER BY page.ordinal"
    ))?;
    let rows = statement
        .query_map([], |row| {
            Ok(RowRecord {
                id: row.get(0)?,
                batch_id: row.get(1)?,
                source_ordinal: row.get(2)?,
                time: row.get(3)?,
                positive_prompt: row.get(4)?,
                character_prompt: row.get(5)?,
                negative_prompt: row.get(6)?,
                note: row.get(7)?,
                artists: row.get(8)?,
                image_folder: row.get(9)?,
                image_path: row.get(10)?,
                stored_image_path: row.get(11)?,
                image_width: row.get(12)?,
                image_height: row.get(13)?,
                generation_model: row.get(14)?,
                generation_sampler: row.get(15)?,
                generation_steps: row.get(16)?,
                generation_seed: row.get(17)?,
                generation_scale: row
                    .get::<_, Option<f64>>(18)?
                    .map(format_generation_scale),
                generation_cfg_rescale: row
                    .get::<_, Option<f64>>(19)?
                    .map(format_generation_scale),
                generation_noise_schedule: row.get(20)?,
                metadata_failed: row.get(21)?,
                vibe_reference_count: row.get(22)?,
                group_id: row.get(23)?,
                group_name: row.get(24)?,
                artist_llm: row.get(25)?,
                favorite: row.get(26)?,
                artist_representative: row.get(27)?,
                tags: Vec::new(),
            })
        })?
        .collect::<Result<Vec<_>, _>>()?;
    Ok(rows)
}

pub(super) fn attach_page_tags(
    connection: &Connection,
    rows: &mut [RowRecord],
) -> Result<(), DatabaseError> {
    let index_by_id: HashMap<i64, usize> = rows
        .iter()
        .enumerate()
        .map(|(index, row)| (row.id, index))
        .collect();
    let mut statement = connection.prepare(&format!(
        "SELECT page.id, tags.name
         FROM {PAGE_ROWS_TABLE} AS page
         JOIN row_tags ON row_tags.row_id = page.id
         JOIN tags ON tags.id = row_tags.tag_id
         ORDER BY page.ordinal, tags.name COLLATE BINARY"
    ))?;
    let mut tag_rows = statement.query([])?;
    while let Some(tag_row) = tag_rows.next()? {
        let row_id: i64 = tag_row.get(0)?;
        let tag: String = tag_row.get(1)?;
        if let Some(index) = index_by_id.get(&row_id) {
            rows[*index].tags.push(tag);
        }
    }
    Ok(())
}

/// Tag 筛选谓词。子查询与外层行无关联，SQLite 只物化一次命中行集合，
/// 避免旧实现对每一行执行相关子查询（万行库下的主要卡顿来源）。
pub(super) fn filter_predicate(mode: TagMatchMode) -> &'static str {
    match mode {
        TagMatchMode::And => {
            "(SELECT COUNT(*) FROM query_filter_tags) = 0
             OR rows.id IN (
                 SELECT row_tags.row_id
                 FROM row_tags
                 JOIN tags ON tags.id = row_tags.tag_id
                 JOIN query_filter_tags ON query_filter_tags.name = tags.name COLLATE BINARY
                 GROUP BY row_tags.row_id
                 HAVING COUNT(*) = (SELECT COUNT(*) FROM query_filter_tags))"
        }
        TagMatchMode::Or => {
            "(SELECT COUNT(*) FROM query_filter_tags) = 0
             OR rows.id IN (
                 SELECT row_tags.row_id
                 FROM row_tags
                 JOIN tags ON tags.id = row_tags.tag_id
                 JOIN query_filter_tags ON query_filter_tags.name = tags.name COLLATE BINARY)"
        }
    }
}

#[cfg(test)]
mod tests {
    use super::super::test_support::database_with_rows;
    use super::super::library_filters::{
        FilterArtistOperator, FilterGenerationNumberField, FilterGenerationTextField,
        FilterGroupOperator, FilterImageDimensionField, FilterNoteOperator,
        FilterNumericComparison, FilterNumericOperator, FilterOrientation, FilterTagOperator,
        FilterTextOperator, FilterVibeOperator,
    };
    use super::*;

    #[test]
    fn favorites_refresh_cached_pages_and_filtered_selection() {
        let mut database = tagged_database();
        let mut query = RowQuery {
            offset: 0, limit: 1, tags: vec![], tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None, single_artist_only: false,
            artist_filter: String::new(), has_vibe: false, untagged_only: false,
            filters: vec![LibraryFilter::Favorite], group_view: false,
            hide_grouped: false, search: String::new(),
        };
        assert_eq!(database.query_rows(&query).unwrap().total_count, 0);
        assert_eq!(database.set_favorite(2, true).unwrap(), 1);
        assert_eq!(database.set_favorite(3, true).unwrap(), 1);
        let first = database.query_rows(&query).unwrap();
        assert_eq!(first.total_count, 2);
        assert_eq!(first.rows[0].id, 2);
        assert!(first.rows[0].favorite);
        query.offset = 1;
        assert_eq!(database.query_rows(&query).unwrap().rows[0].id, 3);
        let selection = super::super::RowSelection::Filtered {
            tags: vec![], tag_mode: TagMatchMode::And, dedupe: DedupeMode::None,
            single_artist_only: false, artist_filter: String::new(), has_vibe: false,
            untagged_only: false, filters: query.filters.clone(),
            search: String::new(), excluded_row_ids: vec![],
        };
        assert_eq!(database.selected_row_ids(&selection).unwrap(), vec![2, 3]);
        query.offset = 0;
        query.tags = vec!["Blue".into()];
        assert_eq!(database.query_rows(&query).unwrap().rows[0].id, 3);
        database.set_favorite(3, false).unwrap();
        assert_eq!(database.query_rows(&query).unwrap().total_count, 0);
        assert_eq!(database.selected_row_ids(&selection).unwrap(), vec![2]);
        assert!(!database.get_rows_by_ids(&[3]).unwrap()[0].favorite);
        assert_eq!(database.set_favorite(9999, true).unwrap(), 0);
    }

    #[test]
    fn paginates_rows_stably_and_attaches_sorted_tags() {
        let mut database = tagged_database();

        let page = database
            .query_rows(&RowQuery {
                offset: 1,
                limit: 2,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
                   dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(page.total_count, 5);
        assert_eq!(
            page.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![2, 3]
        );
        assert_eq!(page.rows[0].tags, vec!["Common", "red"]);
        assert_eq!(page.rows[1].tags, vec!["Blue", "Red"]);
        assert!(page.has_more());
    }

    #[test]
    fn group_and_duplicate_members_sort_before_pagination() {
        let mut database = database_with_rows(5);
        let group = database.create_group("sorted group").unwrap();
        database
            .connection
            .execute("UPDATE rows SET group_id = ?1 WHERE id <= 4", [group.id])
            .unwrap();
        database
            .add_tags_to_rows(&[1, 2, 3, 5], &["Keep".into()])
            .unwrap();
        database.connection.execute_batch(
            "UPDATE rows SET artists = CASE WHEN id <= 4 THEN 'artist:shared' ELSE 'other' END,
                positive_prompt = CASE WHEN id <= 4 THEN 'shared prompt' ELSE 'other' END,
                vibe_signature = CASE WHEN id <= 4 THEN 'shared-vibe' ELSE 'other' END;
             -- Content updates touch updated_at via a trigger; set fixture times afterwards.
             UPDATE rows SET updated_at = CASE id
                    WHEN 1 THEN '2026-01-01T00:00:00.000Z'
                    WHEN 2 THEN '2026-03-01T00:00:00.000Z'
                    WHEN 3 THEN '2026-03-01T00:00:00.000Z'
                    ELSE '2025-01-01T00:00:00.000Z' END;",
        ).unwrap();
        for (sort, expected, filtered) in [
            (SortMode::TimeAsc, vec![1, 2, 3, 4], vec![1, 2, 3]),
            (SortMode::TimeDesc, vec![4, 3, 2, 1], vec![3, 2, 1]),
            (SortMode::RecentlyUpdated, vec![3, 2, 1, 4], vec![3, 2, 1]),
        ] {
            let mut ids = Vec::new();
            for offset in [0, 2] {
                let page = database
                    .get_group_members(group.id, offset, 2, sort)
                    .unwrap();
                assert_eq!(page.total_count, 4);
                assert_eq!(page.has_more(), offset == 0);
                ids.extend(page.rows.into_iter().map(|row| row.id));
            }
            assert_eq!(ids, expected);
            for (mode, key) in [
                (DedupeMode::Artists, "artist:shared"),
                (DedupeMode::PositivePrompt, "shared prompt"),
                (DedupeMode::Vibes, "shared-vibe"),
            ] {
                let mut ids = Vec::new();
                for offset in [0, 2] {
                    let page = database
                        .get_dedupe_cluster_members(
                            mode, key, &["Keep".into()], TagMatchMode::And,
                            false, false, false, &[], false, offset, 2, sort,
                        )
                        .unwrap();
                    assert_eq!(page.total_count, 3);
                    assert_eq!(page.has_more(), offset == 0);
                    ids.extend(page.rows.into_iter().map(|row| row.id));
                }
                assert_eq!(ids, filtered);
            }
        }
    }

    #[test]
    fn supports_all_library_sort_modes() {
        let mut database = database_with_rows(4);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET updated_at = CASE id
                     WHEN 1 THEN '2026-01-01T00:00:00.000Z'
                     WHEN 2 THEN '2026-03-01T00:00:00.000Z'
                     WHEN 3 THEN '2026-03-01T00:00:00.000Z'
                     ELSE '2025-01-01T00:00:00.000Z'
                 END;",
            )
            .unwrap();
        let query = RowQuery {
            offset: 0,
            limit: 10,
            tags: Vec::new(),
            tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None,
            single_artist_only: false,
            artist_filter: String::new(),
            has_vibe: false,
            untagged_only: false,
            filters: vec![],
            group_view: false,
            hide_grouped: false,
            search: String::new(),
        };

        let ids = |page: RowPage| page.rows.into_iter().map(|row| row.id).collect::<Vec<_>>();
        assert_eq!(
            ids(database.query_rows_sorted(&query, SortMode::TimeAsc).unwrap()),
            vec![1, 2, 3, 4]
        );
        assert_eq!(
            ids(database.query_rows_sorted(&query, SortMode::TimeDesc).unwrap()),
            vec![4, 3, 2, 1]
        );
        assert_eq!(
            ids(database
                .query_rows_sorted(&query, SortMode::RecentlyUpdated)
                .unwrap()),
            vec![3, 2, 1, 4]
        );
        assert_eq!(database.row_index_by_id_sorted(2, SortMode::TimeDesc).unwrap(), 2);
        assert_eq!(
            database
                .row_index_by_id_sorted(2, SortMode::RecentlyUpdated)
                .unwrap(),
            1
        );
    }

    #[test]
    fn user_edits_and_tag_changes_touch_recent_update_order() {
        let mut database = database_with_rows(3);
        let query = RowQuery {
            offset: 0,
            limit: 10,
            tags: Vec::new(),
            tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None,
            single_artist_only: false,
            artist_filter: String::new(),
            has_vibe: false,
            untagged_only: false,
            filters: vec![],
            group_view: false,
            hide_grouped: false,
            search: String::new(),
        };
        database
            .connection
            .execute("UPDATE rows SET updated_at = '2000-01-01T00:00:00.000Z'", [])
            .unwrap();
        database.update_note(2, "最近修改").unwrap();
        assert_eq!(
            database
                .query_rows_sorted(&query, SortMode::RecentlyUpdated)
                .unwrap()
                .rows[0]
                .id,
            2
        );

        database
            .connection
            .execute("UPDATE rows SET updated_at = '2000-01-01T00:00:00.000Z'", [])
            .unwrap();
        database.update_positive_prompt(3, "新的提示词").unwrap();
        assert_eq!(
            database
                .query_rows_sorted(&query, SortMode::RecentlyUpdated)
                .unwrap()
                .rows[0]
                .id,
            3
        );

        database
            .connection
            .execute("UPDATE rows SET updated_at = '2000-01-01T00:00:00.000Z'", [])
            .unwrap();
        database.add_tags_to_rows(&[1], &["最近标签".into()]).unwrap();
        assert_eq!(
            database
                .query_rows_sorted(&query, SortMode::RecentlyUpdated)
                .unwrap()
                .rows[0]
                .id,
            1
        );
    }

    #[test]
    fn and_filter_requires_every_case_sensitive_tag() {
        let mut database = tagged_database();

        let page = query(&mut database, &["Red", "Blue"], TagMatchMode::And);
        let wrong_case = query(&mut database, &["red", "Blue"], TagMatchMode::And);

        assert_eq!(page.total_count, 1);
        assert_eq!(page.rows[0].id, 3);
        assert_eq!(wrong_case.total_count, 0);
    }

    #[test]
    fn or_filter_matches_any_case_sensitive_tag() {
        let mut database = tagged_database();

        let page = query(&mut database, &["Red", "Blue"], TagMatchMode::Or);
        let lowercase = query(&mut database, &["red"], TagMatchMode::Or);

        assert_eq!(page.total_count, 3);
        assert_eq!(
            page.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![1, 3, 4]
        );
        assert_eq!(
            lowercase.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![2]
        );
    }

    #[test]
    fn dedupes_nonempty_keys_and_keeps_empty_rows_visible() {
        let mut database = tagged_database();
        database
            .connection
            .execute_batch(
                "UPDATE rows SET positive_prompt = CASE id
                     WHEN 1 THEN ' same '
                     WHEN 2 THEN 'same'
                     WHEN 3 THEN ''
                     WHEN 4 THEN NULL
                     ELSE 'Same'
                 END;
                 UPDATE rows SET artists = CASE id
                     WHEN 1 THEN 'artist A'
                     WHEN 2 THEN 'artist A'
                     WHEN 3 THEN ' artist B '
                     WHEN 4 THEN 'artist B'
                     ELSE ''
                 END;",
            )
            .unwrap();

        let prompts = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 100,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
               dedupe: DedupeMode::PositivePrompt,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();
        assert_eq!(prompts.total_count, 4);
        assert_eq!(
            prompts.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![1, 3, 4, 5]
        );

        let artists = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 100,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
               dedupe: DedupeMode::Artists,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();
        assert_eq!(artists.total_count, 3);
        assert_eq!(
            artists.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![1, 3, 5]
        );
    }

    #[test]
    fn applies_tag_filter_before_deduplication() {
        let mut database = tagged_database();
        database
            .connection
            .execute(
                "UPDATE rows SET positive_prompt = 'shared' WHERE id IN (1, 2, 3)",
                [],
            )
            .unwrap();

        let page = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 100,
                tags: vec!["Red".into()],
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::PositivePrompt,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(page.total_count, 1);
        assert_eq!(page.rows[0].id, 1);
    }

    #[test]
    fn lists_all_tag_counts_in_binary_order() {
        let mut database = tagged_database();
        database.create_tag("Unused").unwrap();

        let tags = database.list_tags().unwrap();

        assert_eq!(
            tags,
            vec![
                TagSummary {
                    name: "Blue".into(),
                    row_count: 2
                },
                TagSummary {
                    name: "Common".into(),
                    row_count: 2
                },
                TagSummary {
                    name: "Red".into(),
                    row_count: 2
                },
                TagSummary {
                    name: "Unused".into(),
                    row_count: 0
                },
                TagSummary {
                    name: "red".into(),
                    row_count: 1
                },
            ]
        );
    }

    #[test]
    fn rejects_invalid_page_sizes() {
        let mut database = tagged_database();
        for limit in [0, MAX_PAGE_SIZE + 1] {
            let error = database
                .query_rows(&RowQuery {
                    offset: 0,
                    limit,
                    tags: Vec::new(),
                    tag_mode: TagMatchMode::And,
                    dedupe: DedupeMode::None,
                    single_artist_only: false,
                    artist_filter: String::new(),
                    has_vibe: false,
                    untagged_only: false,
                    filters: vec![],
                    group_view: false,
                    hide_grouped: false,
                    search: String::new(),
                })
                .unwrap_err();
            assert!(matches!(error, DatabaseError::InvalidPageSize { .. }));
        }
    }

    #[test]
    fn cached_filter_serves_pages_and_refreshes_after_bump() {
        let mut database = database_with_rows(5);

        assert_eq!(query(&mut database, &[], TagMatchMode::And).total_count, 5);
        // 同参数二次查询走缓存，结果一致
        let cached = query(&mut database, &[], TagMatchMode::And);
        assert_eq!(cached.total_count, 5);
        assert_eq!(cached.rows.len(), 5);

        super::super::test_support::append_rows(
            &mut database,
            &[super::super::batches::NewRow {
                source_ordinal: 99,
                identity: r"file:d:\test\extra.png".into(),
                ..super::super::batches::NewRow::default()
            }],
        );
        // 缓存语义：数据变更后、失效前结果保持不变
        assert_eq!(query(&mut database, &[], TagMatchMode::And).total_count, 5);

        database.bump_data_version();
        assert_eq!(query(&mut database, &[], TagMatchMode::And).total_count, 6);
    }

    #[test]
    fn search_matches_character_prompt() {
        let mut database = database_with_rows(3);
        database
            .connection
            .execute(
                "UPDATE rows SET character_prompt = 'silver hair, unique_role_token' WHERE id = 2",
                [],
            )
            .unwrap();

        let result = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 10,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: "UNIQUE_ROLE_TOKEN".into(),
            })
            .unwrap();

        assert_eq!(result.total_count, 1);
        assert_eq!(result.rows[0].id, 2);
        assert_eq!(
            result.rows[0].character_prompt.as_deref(),
            Some("silver hair, unique_role_token")
        );
    }

    #[test]
    fn search_matches_multiline_prompt_after_single_line_paste_normalizes_line_breaks() {
        let mut database = database_with_rows(3);
        let prompt = concat!(
            "masterpiece, best quality, extremely detailed,\r\n",
            "0.5::artist:maidcode1023 ::,\r\n",
            "0.5::artist:fusuma_(ramunezake)::,\r\n",
            "artist:sune (mugendai),\r\n",
            "artist:takepoison,\r\n",
            "1.5::artist:riri (ri0177)::,\r\n",
            "1.2::artist:izumi_nanase::,\r\n",
            "0.5::artist:chen_bin::,\r\n",
            ", year 2024, -3::artist collaboration::\r\n",
            "\r\n",
            "1girl, white long hair, blue eyes, \r\n",
            "maid, black and white maid outfit,white pantyhose,detailed maid outfit, ",
            "frilled apron, lace trim, maid headdress, wrist cuffs, lace collar, ribbon,\r\n",
            "colored inner hair(blue),\r\n",
            "\r\n",
            "soft smile, sit, hair flower(white flower)\r\n",
            ", very aesthetic, masterpiece, no text"
        );
        database
            .connection
            .execute(
                "UPDATE rows SET positive_prompt = ?1 WHERE id = 2",
                [prompt],
            )
            .unwrap();

        // Chromium/WebView 会把换行变为空格，其他输入环境可能直接删除换行。
        let pasted_variants = [
            prompt.replace("\r\n", " ").replace(['\r', '\n'], " "),
            prompt.replace(['\r', '\n'], ""),
        ];
        for pasted in pasted_variants {
            assert!(pasted.len() > 100);
            let result = database
                .query_rows(&RowQuery {
                    offset: 0,
                    limit: 10,
                    tags: Vec::new(),
                    tag_mode: TagMatchMode::And,
                    dedupe: DedupeMode::None,
                    single_artist_only: false,
                    artist_filter: String::new(),
                    has_vibe: false,
                    untagged_only: false,
                    filters: vec![],
                    group_view: false,
                    hide_grouped: false,
                    search: pasted,
                })
                .unwrap();

            assert_eq!(result.total_count, 1);
            assert_eq!(result.rows[0].id, 2);
            assert_eq!(result.rows[0].positive_prompt.as_deref(), Some(prompt));
        }
    }

    #[test]
    fn search_normalizes_separators_and_falls_back_only_without_full_matches() {
        let mut database = database_with_rows(3);
        database.update_note(1, "alpha，\r\n\t\u{3000}_-beta").unwrap();
        database.update_note(2, "beta elsewhere alpha").unwrap();
        database.update_note(3, "alpha only").unwrap();
        let mut query = RowQuery {
            offset: 0, limit: 1, tags: vec![], tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None, single_artist_only: false,
            artist_filter: String::new(), has_vibe: false, untagged_only: false,
            filters: vec![], group_view: false, hide_grouped: false,
            search: "alpha beta".into(),
        };
        for separator in super::SEARCH_SEPARATORS.chars() {
            query.search = format!("alpha{separator}beta");
            let page = database.query_rows(&query).unwrap();
            assert_eq!(page.total_count, 1);
            assert_eq!(page.rows[0].id, 1);
        }
        query.offset = 1;
        assert!(database.query_rows(&query).unwrap().rows.is_empty());
        database.update_note(1, "unrelated").unwrap();
        query.offset = 0;
        let page = database.query_rows(&query).unwrap();
        assert_eq!(page.total_count, 1);
    }

    #[test]
    fn cached_search_preserves_filtered_fallback_and_field_boundaries() {
        let mut database = database_with_rows(5);
        database.connection.execute_batch(
            "UPDATE rows SET positive_prompt = NULL, character_prompt = NULL, negative_prompt = NULL, artists = NULL;
             UPDATE rows SET note = 'alpha beta' WHERE id = 1;
             UPDATE rows SET note = 'alpha', artists = 'beta' WHERE id = 2;
             UPDATE rows SET note = 'beta elsewhere alpha', artists = 'beta' WHERE id = 3;
             UPDATE rows SET note = 'alpha only' WHERE id = 4;
             UPDATE rows SET note = 'literal %_ marker' WHERE id = 5;",
        ).unwrap();
        database.add_tags_to_rows(&[2, 3], &["scope".into()]).unwrap();
        let mut query = RowQuery {
            offset: 0, limit: 200, tags: vec![], tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None, single_artist_only: false,
            artist_filter: String::new(), has_vibe: false, untagged_only: false,
            filters: vec![], group_view: false, hide_grouped: false,
            search: "alpha beta".into(),
        };
        let ids = |db: &mut Database, query: &RowQuery| db.query_rows(query).unwrap().rows.iter().map(|row| row.id).collect::<Vec<_>>();
        assert_eq!(ids(&mut database, &query), vec![1]);
        query.tags = vec!["scope".into()];
        assert_eq!(ids(&mut database, &query), vec![2, 3], "full match outside filters must not suppress fallback");
        query.dedupe = DedupeMode::Artists;
        assert_eq!(ids(&mut database, &query), vec![2]);
        query.dedupe = DedupeMode::None;
        query.search = "alphabeta".into();
        assert!(ids(&mut database, &query).is_empty(), "full match must not cross field boundaries");
        query.search = "alpha alpha".into();
        assert_eq!(ids(&mut database, &query), vec![2, 3]);
        query.tags.clear();
        query.search = "%".into();
        assert_eq!(ids(&mut database, &query), vec![5], "SQL wildcards remain literal text");
        database.update_note(5, "changed").unwrap();
        database.bump_data_version();
        assert!(ids(&mut database, &query).is_empty(), "edits must invalidate search text as well as result IDs");
    }

    #[test]
    fn search_matches_note() {
        let mut database = database_with_rows(3);
        database.update_note(2, "夏日海边预设").unwrap();

        let result = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 10,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: "海边".into(),
            })
            .unwrap();

        assert_eq!(result.total_count, 1);
        assert_eq!(result.rows[0].id, 2);
        assert_eq!(result.rows[0].note.as_deref(), Some("夏日海边预设"));
    }

    #[test]
    fn filters_rows_with_vibe_references() {
        let mut database = database_with_rows(4);
        database
            .connection
            .execute(
                "UPDATE rows
                 SET vibe_reference_count = CASE id WHEN 2 THEN 1 WHEN 4 THEN 3 ELSE 0 END",
                [],
            )
            .unwrap();
        database.bump_data_version();

        let result = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 10,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: true,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(result.total_count, 2);
        assert_eq!(
            result.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![2, 4]
        );
        assert_eq!(result.rows[1].vibe_reference_count, Some(3));
    }

    #[test]
    fn filters_rows_without_tags() {
        let mut database = database_with_rows(4);
        database
            .add_tags_to_rows(&[1, 3], &["tagged".into()])
            .unwrap();

        let result = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 10,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: true,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(result.total_count, 2);
        assert_eq!(
            result.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![2, 4]
        );

        // 移除 Tag 后重新可见（生产路径由 runtime 在写库后失效查询缓存，这里手动模拟）
        database
            .remove_tags_from_rows(&[1], &["tagged".into()])
            .unwrap();
        database.bump_data_version();
        let refreshed = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 10,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: true,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();
        assert_eq!(refreshed.total_count, 3);
    }

    #[test]
    fn single_artist_filter_rejects_canonical_and_legacy_multi_artist_strings() {
        let mut database = database_with_rows(4);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET artists = CASE id
                     WHEN 1 THEN 'artist:solo'
                     WHEN 2 THEN 'artist:a' || CHAR(10) || 'artist:b'
                     WHEN 3 THEN 'artist:a, artist:b'
                     ELSE ''
                 END;",
            )
            .unwrap();
        database.bump_data_version();

        let result = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 10,
                tags: Vec::new(),
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: true,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(result.total_count, 1);
        assert_eq!(result.rows[0].id, 1);
    }

    #[test]
    fn exact_artist_filter_matches_trimmed_whole_value_and_combines_with_search() {
        let mut database = database_with_rows(4);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET
                    artists = CASE id
                        WHEN 1 THEN 'artist:a'
                        WHEN 2 THEN '  artist:a  '
                        WHEN 3 THEN 'artist:a' || CHAR(10) || 'artist:b'
                        ELSE 'artist:A'
                    END,
                    positive_prompt = CASE id WHEN 1 THEN 'needle' ELSE 'other' END;",
            )
            .unwrap();
        database.bump_data_version();

        let query = RowQuery {
            offset: 0,
            limit: 10,
            tags: Vec::new(),
            tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None,
            single_artist_only: false,
            artist_filter: "  artist:a  ".into(),
            has_vibe: false,
            untagged_only: false,
            filters: vec![],
            group_view: false,
            hide_grouped: false,
            search: String::new(),
        };
        let exact = database.query_rows(&query).unwrap();
        assert_eq!(
            exact.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![1, 2]
        );

        let combined = database
            .query_rows(&RowQuery {
                search: "needle".into(),
                ..query
            })
            .unwrap();
        assert_eq!(combined.total_count, 1);
        assert_eq!(combined.rows[0].id, 1);
    }

    #[test]
    fn structured_filters_combine_tag_artist_vibe_and_group_with_and() {
        let mut database = tagged_database();
        let group = database.create_group("已归档").unwrap();
        database
            .connection
            .execute_batch(&format!(
                "UPDATE rows SET artists = CASE id
                     WHEN 1 THEN 'artist:Alice'
                     WHEN 2 THEN 'artist:alice' || CHAR(10) || 'artist:bob'
                     WHEN 3 THEN NULL
                     ELSE 'artist:alice' END,
                 vibe_reference_count = CASE id WHEN 3 THEN 2 ELSE 0 END,
                 group_id = CASE id WHEN 4 THEN {} ELSE NULL END;",
                group.id
            ))
            .unwrap();

        let page = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 100,
                tags: vec![],
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![
                    LibraryFilter::Tag {
                        operator: FilterTagOperator::HasAny,
                        values: vec!["Red".into()],
                    },
                    LibraryFilter::Artist {
                        operator: FilterArtistOperator::ContainsAny,
                        values: vec!["ALICE".into()],
                    },
                    LibraryFilter::Artist {
                        operator: FilterArtistOperator::IsSingle,
                        values: vec![],
                    },
                    LibraryFilter::Vibe {
                        operator: FilterVibeOperator::HasNone,
                        comparison: None,
                    },
                    LibraryFilter::Group {
                        operator: FilterGroupOperator::IsEmpty,
                        group_id: None,
                    },
                ],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(page.rows.iter().map(|row| row.id).collect::<Vec<_>>(), vec![1]);
    }

    #[test]
    fn structured_filters_cover_notes_metadata_dimensions_and_generation_fields() {
        let mut database = database_with_rows(3);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET
                   note = CASE id WHEN 2 THEN '夏日草稿' ELSE '' END,
                   metadata_failed = CASE id WHEN 3 THEN 1 ELSE 0 END,
                   image_width = CASE id WHEN 1 THEN 1200 WHEN 2 THEN 832 ELSE 1024 END,
                   image_height = CASE id WHEN 1 THEN 800 WHEN 2 THEN 1216 ELSE 1024 END,
                   generation_model = CASE id WHEN 2 THEN 'NovelAI Diffusion V4.5' ELSE 'V3' END,
                   generation_steps = CASE id WHEN 2 THEN 28 ELSE 20 END;",
            )
            .unwrap();

        let page = database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 100,
                tags: vec![],
                tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![
                    LibraryFilter::Note {
                        operator: FilterNoteOperator::Contains,
                        value: "夏日".into(),
                        case_sensitive: false,
                    },
                    LibraryFilter::Metadata { parsed: true },
                    LibraryFilter::Orientation {
                        orientation: FilterOrientation::Portrait,
                    },
                    LibraryFilter::ImageDimension {
                        field: FilterImageDimensionField::Width,
                        comparison: FilterNumericComparison {
                            operator: FilterNumericOperator::GreaterOrEqual,
                            value: 800.0,
                            second_value: None,
                        },
                    },
                    LibraryFilter::GenerationText {
                        field: FilterGenerationTextField::Model,
                        operator: FilterTextOperator::Contains,
                        value: "v4.5".into(),
                        case_sensitive: false,
                    },
                    LibraryFilter::GenerationNumber {
                        field: FilterGenerationNumberField::Steps,
                        comparison: FilterNumericComparison {
                            operator: FilterNumericOperator::Between,
                            value: 25.0,
                            second_value: Some(30.0),
                        },
                    },
                ],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(page.rows.iter().map(|row| row.id).collect::<Vec<_>>(), vec![2]);
    }

    #[test]
    fn cache_hit_paging_returns_consistent_pages() {
        let mut database = database_with_rows(10);
        let page_query = |offset: u64| RowQuery {
            offset,
            limit: 3,
            tags: Vec::new(),
            tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None,
            single_artist_only: false,
            artist_filter: String::new(),
            has_vibe: false,
            untagged_only: false,
            filters: vec![],
            group_view: false,
            hide_grouped: false,
            search: String::new(),
        };

        let first = database.query_rows(&page_query(0)).unwrap();
        let second = database.query_rows(&page_query(3)).unwrap();
        let last = database.query_rows(&page_query(9)).unwrap();

        assert_eq!(first.rows.iter().map(|r| r.id).collect::<Vec<_>>(), vec![1, 2, 3]);
        assert_eq!(second.rows.iter().map(|r| r.id).collect::<Vec<_>>(), vec![4, 5, 6]);
        assert_eq!(last.rows.iter().map(|r| r.id).collect::<Vec<_>>(), vec![10]);
        assert_eq!(last.total_count, 10);
    }

    #[test]
    fn scratch_member_queries_do_not_clobber_cached_filter() {
        let mut database = database_with_rows(4);
        database
            .connection
            .execute("UPDATE rows SET artists = 'artist:a' WHERE id IN (1, 2)", [])
            .unwrap();
        database.bump_data_version();

        let page_query = |offset: u64| RowQuery {
            offset,
            limit: 2,
            tags: Vec::new(),
            tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None,
            single_artist_only: false,
            artist_filter: String::new(),
            has_vibe: false,
            untagged_only: false,
            filters: vec![],
            group_view: false,
            hide_grouped: false,
            search: String::new(),
        };
        assert_eq!(database.query_rows(&page_query(0)).unwrap().total_count, 4);

        // 成员查询使用 scratch 表，不得破坏已缓存的主筛选结果
        let members = database
            .get_dedupe_cluster_members(
                DedupeMode::Artists,
                "artist:a",
                &[],
                TagMatchMode::And,
                false,
                false,
                false,
                &[],
                false,
                0,
                100,
                SortMode::TimeAsc,
            )
            .unwrap();
        assert_eq!(members.total_count, 2);

        let page = database.query_rows(&page_query(2)).unwrap();
        assert_eq!(page.rows.iter().map(|r| r.id).collect::<Vec<_>>(), vec![3, 4]);
        assert_eq!(page.total_count, 4);
    }

    #[test]
    fn paginates_ten_thousand_rows_without_loading_all_records() {
        let mut database = database_with_rows(10_000);

        let page = database
            .query_rows(&RowQuery {
                offset: 9_900,
                limit: 100,
                tags: Vec::new(),
                tag_mode: TagMatchMode::Or,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap();

        assert_eq!(page.total_count, 10_000);
        assert_eq!(page.rows.len(), 100);
        assert_eq!(page.rows.first().unwrap().source_ordinal, 9_902);
        assert_eq!(page.rows.last().unwrap().source_ordinal, 10_001);
        assert!(!page.has_more());
    }

    /// 万行库性能基准（手动运行）：
    /// cargo test --release bench_ten_thousand -- --ignored --nocapture
    #[test]
    #[ignore = "性能基准，手动运行"]
    fn bench_ten_thousand_row_filters() {
        use std::time::Instant;

        let filler = "masterpiece, best quality, highly detailed background, cinematic lighting, \
                      1girl, solo, long hair, looking at viewer, intricate details, depth of field, \
                      soft shadows, volumetric light, dynamic angle, wide shot, detailed face"
            .repeat(3);
        let rows: Vec<super::super::batches::NewRow> = (1..=10_000)
            .map(|index| super::super::batches::NewRow {
                source_ordinal: index as u32,
                identity: format!(r"file:d:\bench\{index}.png"),
                positive_prompt: Some(format!("artist:painter{}, {filler}", index % 97)),
                artists: Some(format!("artist:painter{}", index % 97)),
                ..super::super::batches::NewRow::default()
            })
            .collect();
        let mut database = Database::open_in_memory().unwrap();
        super::super::test_support::append_rows(&mut database, &rows);
        let all_ids: Vec<i64> = (1..=10_000).collect();
        database
            .add_tags_to_rows(&all_ids, &["常用".into()])
            .unwrap();
        let half_ids: Vec<i64> = (1..=5_000).collect();
        database
            .add_tags_to_rows(&half_ids, &["精选".into()])
            .unwrap();
        database.bump_data_version();

        let base = RowQuery {
            offset: 0,
            limit: 200,
            tags: Vec::new(),
            tag_mode: TagMatchMode::And,
            dedupe: DedupeMode::None,
            single_artist_only: false,
            artist_filter: String::new(),
            has_vibe: false,
            untagged_only: false,
            filters: vec![],
            group_view: false,
            hide_grouped: false,
            search: String::new(),
        };
        let mut bench = |label: &str, query: &RowQuery| {
            let start = Instant::now();
            let page = database.query_rows(query).unwrap();
            println!(
                "{label}: {:?}（命中 {} 行）",
                start.elapsed(),
                page.total_count
            );
        };

        bench("无筛选 首查（全量物化）", &base);
        bench("无筛选 缓存翻页", &RowQuery { offset: 5_000, ..base.clone() });
        let tagged = RowQuery {
            tags: vec!["常用".into(), "精选".into()],
            ..base.clone()
        };
        bench("双 Tag AND 首查", &tagged);
        bench("双 Tag AND 缓存翻页", &RowQuery { offset: 2_000, ..tagged.clone() });
        let searched = RowQuery {
            search: "painter42".into(),
            ..base.clone()
        };
        bench("文本搜索 首查（INSTR 全扫）", &searched);
        bench("文本搜索 缓存翻页", &RowQuery { offset: 50, ..searched.clone() });
        let deduped = RowQuery {
            dedupe: DedupeMode::Artists,
            ..base.clone()
        };
        bench("画师串去重 首查", &deduped);
    }

    /// Same fixture and queries before/after search changes; no original images needed.
    #[test]
    #[ignore = "60k-row search performance benchmark, run manually"]
    fn bench_sixty_thousand_row_search() {
        use std::time::Instant;
        let filler = "masterpiece, best quality, cinematic lighting, 1girl, solo, long hair, detailed background, 海边, soft shadows, ".repeat(12);
        let rows: Vec<super::super::batches::NewRow> = (1..=60_000)
            .map(|index| super::super::batches::NewRow {
                source_ordinal: index,
                identity: format!("file:d:/bench/{index}.png"),
                image_path: Some(format!("d:/bench/{index}.png")),
                positive_prompt: Some(format!("artist:painter{}, {filler}", index % 97)),
                character_prompt: Some("1girl, blue eyes, white dress".repeat(8)),
                negative_prompt: Some("lowres, bad anatomy, blurry".repeat(8)),
                artists: Some(format!("artist:painter{}", index % 97)),
                ..super::super::batches::NewRow::default()
            }).collect();
        let mut database = Database::open_in_memory().unwrap();
        super::super::test_support::append_rows(&mut database, &rows);
        drop(rows);
        for (search, expected) in [("painter42", 619), ("notfound", 0), ("white dress", 60_000), ("dress girl", 60_000), ("海边", 60_000)] {
            let query = RowQuery {
                offset: 0, limit: 200, tags: vec![], tag_mode: TagMatchMode::And,
                dedupe: DedupeMode::None, single_artist_only: false,
                artist_filter: String::new(), has_vibe: false, untagged_only: false,
                filters: vec![], group_view: false, hide_grouped: false,
                search: search.into(),
            };
            let start = Instant::now();
            let page = database.query_rows(&query).unwrap();
            println!("60k search {search:?}: {:?}, {} hits", start.elapsed(), page.total_count);
            assert_eq!(page.total_count, expected);
            let start = Instant::now();
            database.query_rows(&RowQuery { offset: 200, ..query }).unwrap();
            println!("60k cached next page: {:?}", start.elapsed());
        }
        let pages: i64 = database.connection.query_row("PRAGMA temp.page_count", [], |r| r.get(0)).unwrap();
        let page_size: i64 = database.connection.query_row("PRAGMA temp.page_size", [], |r| r.get(0)).unwrap();
        println!("60k temporary tables: {:.1} MiB", (pages * page_size) as f64 / 1_048_576.0);
    }

    fn query(database: &mut Database, tags: &[&str], mode: TagMatchMode) -> RowPage {
        database
            .query_rows(&RowQuery {
                offset: 0,
                limit: 100,
                tags: tags.iter().map(|tag| (*tag).to_owned()).collect(),
                tag_mode: mode,
                dedupe: DedupeMode::None,
                single_artist_only: false,
                artist_filter: String::new(),
                has_vibe: false,
                untagged_only: false,
                filters: vec![],
                group_view: false,
                hide_grouped: false,
                search: String::new(),
            })
            .unwrap()
    }

    fn tagged_database() -> Database {
        let mut database = database_with_rows(5);
        database
            .add_tags_to_rows(&[1, 2], &["Common".into()])
            .unwrap();
        database.add_tags_to_rows(&[1, 3], &["Red".into()]).unwrap();
        database.add_tags_to_rows(&[2], &["red".into()]).unwrap();
        database
            .add_tags_to_rows(&[3, 4], &["Blue".into()])
            .unwrap();
        database
    }

    #[test]
    fn list_distinct_artists_splits_dedupes_and_sorts() {
        let database = database_with_rows(4);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET artists = CASE id
                     WHEN 1 THEN 'artist:b'
                     WHEN 2 THEN 'artist:a' || CHAR(10) || 'artist:b'
                     WHEN 3 THEN '  artist:c  '
                     WHEN 4 THEN ''
                 END;",
            )
            .unwrap();

        let artists = database.list_distinct_artists().unwrap();
        assert_eq!(artists, vec!["artist:a", "artist:b", "artist:c"]);
    }

    #[test]
    fn row_ids_with_artists_matches_exact_trimmed_value() {
        let database = database_with_rows(4);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET artists = CASE id
                     WHEN 1 THEN 'artist:a'
                     WHEN 2 THEN ' artist:a '
                     WHEN 3 THEN 'artist:b'
                     WHEN 4 THEN NULL
                 END;",
            )
            .unwrap();

        assert_eq!(database.row_ids_with_artists("artist:a").unwrap(), vec![1, 2]);
        assert_eq!(database.row_ids_with_artists("artist:b").unwrap(), vec![3]);
        assert!(database.row_ids_with_artists("   ").unwrap().is_empty());
        assert!(
            database
                .row_ids_with_artists("artist:missing")
                .unwrap()
                .is_empty()
        );
    }

    #[test]
    fn row_index_by_id_uses_current_library_order_and_handles_gaps() {
        let database = database_with_rows(5);
        database
            .connection
            .execute("DELETE FROM rows WHERE id = 2", [])
            .unwrap();

        assert_eq!(database.row_index_by_id(1).unwrap(), 0);
        assert_eq!(database.row_index_by_id(3).unwrap(), 1);
        assert_eq!(database.row_index_by_id(5).unwrap(), 3);
        assert!(matches!(
            database.row_index_by_id(2),
            Err(DatabaseError::RowNotFound(2))
        ));
    }

    #[test]
    fn list_dedupe_clusters_excludes_singletons() {
        let mut database = database_with_rows(3);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET artists = CASE id
                     WHEN 1 THEN 'artist:a'
                     WHEN 2 THEN 'artist:a'
                     WHEN 3 THEN 'artist:solo'
                 END,
                 note = CASE id WHEN 1 THEN 'keep one' WHEN 2 THEN 'keep two' ELSE 'skip' END;",
            )
            .unwrap();

        let filters = vec![LibraryFilter::Note {
            operator: FilterNoteOperator::Contains,
            value: "KEEP".into(),
            case_sensitive: false,
        }];

        let duplicates = database
            .list_dedupe_clusters(
                DedupeMode::Artists,
                &[],
                TagMatchMode::And,
                false,
                false,
                false,
                &filters,
                false,
            )
            .unwrap();
        assert_eq!(duplicates.len(), 1);
        assert_eq!(duplicates[0].key, "artist:a");
        assert_eq!(duplicates[0].member_count, 2);

        let members = database
            .get_dedupe_cluster_members(
                DedupeMode::Artists,
                "artist:a",
                &[],
                TagMatchMode::And,
                false,
                false,
                false,
                &filters,
                false,
                0,
                100,
                SortMode::TimeAsc,
            )
            .unwrap();
        assert_eq!(members.rows.iter().map(|row| row.id).collect::<Vec<_>>(), vec![1, 2]);
    }

    #[test]
    fn vibe_dedupe_clusters_group_by_signature_and_support_alias() {
        let mut database = database_with_rows(4);
        database
            .connection
            .execute_batch(
                "UPDATE rows SET
                     vibe_reference_count = CASE id WHEN 4 THEN 0 ELSE 2 END,
                     vibe_signature = CASE id
                         WHEN 1 THEN 'sig-a'
                         WHEN 2 THEN 'sig-a'
                         WHEN 3 THEN 'sig-solo'
                         WHEN 4 THEN NULL
                     END;",
            )
            .unwrap();

        let clusters = database
            .list_dedupe_clusters(
                DedupeMode::Vibes,
                &[],
                TagMatchMode::And,
                false,
                false,
                false,
                &[],
                false,
            )
            .unwrap();
        assert_eq!(clusters.len(), 1);
        assert_eq!(clusters[0].key, "sig-a");
        assert_eq!(clusters[0].member_count, 2);
        assert_eq!(clusters[0].alias, None);

        database
            .set_dedupe_alias(DedupeMode::Vibes, "sig-a", "同一组 VIBE")
            .unwrap();
        let clusters = database
            .list_dedupe_clusters(
                DedupeMode::Vibes,
                &[],
                TagMatchMode::And,
                false,
                false,
                false,
                &[],
                false,
            )
            .unwrap();
        assert_eq!(clusters[0].alias.as_deref(), Some("同一组 VIBE"));

        let members = database
            .get_dedupe_cluster_members(
                DedupeMode::Vibes,
                "sig-a",
                &[],
                TagMatchMode::And,
                false,
                false,
                false,
                &[],
                false,
                0,
                100,
                SortMode::TimeAsc,
            )
            .unwrap();
        assert_eq!(
            members.rows.iter().map(|row| row.id).collect::<Vec<_>>(),
            vec![1, 2]
        );
    }
}
