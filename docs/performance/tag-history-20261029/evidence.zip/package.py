from pathlib import Path
import json, hashlib, zipfile
root=Path('D:/Agent/智能表格')
lab=Path('D:/Agent/Agent_temp/memory-optimize-20261029')
out=root/'docs/performance/tag-history-20261029'
results={}
for file in sorted((lab/'results').glob('*')):
    if file.suffix=='.jsonl':
        results[file.name]=[json.loads(line) for line in file.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    elif file.suffix=='.json':results[file.name]=json.loads(file.read_text(encoding='utf-8-sig'))
files=['src-tauri/src/db/tag_history.rs','src-tauri/src/db/tags.rs','src-tauri/src/db/mod.rs','src-tauri/src/app/commands/tags.rs','src-tauri/src/app/runtime/tags.rs','src-tauri/src/lib.rs','src/lib/api/tags.ts','src/lib/dev/ipc-mock.ts','src/react/state/history.ts','src/react/state/library-changes.ts','src/react/state/library.ts','src/react/ui/FieldEditor.tsx','src/react/views/DetailContents.tsx','src/react/views/TagAssignDialog.tsx']
results['productionSha256']={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files}
(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
    for file in lab.iterdir():
        if file.is_file() and file.suffix in ['.py','.cjs','.mjs','.rs','.md','.png']:z.write(file,file.name)
    for file in (lab/'backend').rglob('*'):
        if file.is_file():z.write(file,file.relative_to(lab).as_posix())
    for file in (lab/'results').glob('*'):z.write(file,file.relative_to(lab).as_posix())
    for name in files:z.write(root/name,'production/'+name)
print(json.dumps({'resultsBytes':(out/'results.json').stat().st_size,'evidenceBytes':(out/'evidence.zip').stat().st_size}))
