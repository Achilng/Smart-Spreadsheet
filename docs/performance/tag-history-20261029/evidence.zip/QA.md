# Verification inventory

- Actual Rust transaction: mixed additions/removals, duplicate IDs and trimmed/case-sensitive tags, no-op delta, filtered selection frozen before edits, rollback after partial write failure.
- Undo/redo: preserve pre-existing tags and unrelated tags/text/group changes; missing row or injected failure rolls back all associations; no-op edits add no history entry; retain existing 50-entry policy.
- UI with normal controls: tag dialog stage/apply/cancel, visible confirmation and tags; undo/redo via keyboard; single note/prompt edit and undo; failure/retry without duplicate apply.
- Refresh: unfiltered/time ordering uses bounded cached-row reads without query_rows or list_tags for text; tags still refresh counts; search/tag/advanced filters, dedupe, recentlyUpdated, group view use full query; multiple cached pages fall back if >201 reads; navigation/pending request/external edit must not accept stale responses.
- Related views: reset token still invalidates group/duplicate member caches; toolbox notification remains; external toolbox edit still refreshes main and clears history.
- Browser visual pass at 1440x900 and 900x600: tag dialog, saved detail, filtering after mutation; inspect screenshots and region fit. No visual design changes intended.
- Memory: isolate final history functions with real delta response shape; compare original recorded baseline and run 10k/70k three-edit sequences under 256 MiB, no swap, serial containers. Actual Rust database integration separate from mocked browser IPC.
- Build/typecheck and relevant existing Rust tests. Do not add unit tests or touch real libraries.
