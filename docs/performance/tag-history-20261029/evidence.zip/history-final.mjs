import { create, getRowsByIds, restoreMutableRowStates, selectedRowIds, afterLibraryMutation, notify, runTask, useTasks, errorText, registerHistoryClearer, applyTagChanges } from './adapter.mjs';
export function mutableRowState(row) {
    return {
        rowId: row.id,
        positivePrompt: row.positivePrompt,
        characterPrompt: row.characterPrompt,
        negativePrompt: row.negativePrompt,
        note: row.note,
        artists: row.artists,
        artistLlm: row.artistLlm ?? null,
        tags: [...row.tags],
        groupId: row.groupId,
    };
}
const undoStack = [];
const redoStack = [];
let activeGroup = null;
export const useHistory = create(() => ({ undoCount: 0, redoCount: 0, busy: false, undoLabel: null, redoLabel: null }));
const sync = () => useHistory.setState({ undoCount: undoStack.length, redoCount: redoStack.length, undoLabel: undoStack.at(-1)?.label ?? null, redoLabel: redoStack.at(-1)?.label ?? null });
export function recordHistory(action) {
    if (useHistory.getState().busy)
        return;
    redoStack.length = 0;
    if (activeGroup) {
        activeGroup.actions.push(action);
        return;
    }
    undoStack.push(action);
    if (undoStack.length > 50)
        undoStack.shift();
    sync();
}
export function beginHistoryGroup(label) {
    if (useHistory.getState().busy || activeGroup)
        return false;
    activeGroup = { label, actions: [] };
    return true;
}
export function commitHistoryGroup() {
    const group = activeGroup;
    activeGroup = null;
    if (!group?.actions.length)
        return false;
    recordHistory({ label: group.label,
        undo: async () => { for (const action of [...group.actions].reverse())
            await action.undo(); },
        redo: async () => { for (const action of group.actions)
            await action.redo(); },
    });
    return true;
}
export function clearHistory() { undoStack.length = 0; redoStack.length = 0; activeGroup = null; sync(); }
registerHistoryClearer(clearHistory);
async function applyHistory(direction) {
    if (useHistory.getState().busy || activeGroup)
        return;
    const label = direction === "undo" ? "撤销" : "重做";
    if (useTasks.getState().busy) {
        notify(`当前有任务进行中，暂时无法${label}。`, "error");
        return;
    }
    const source = direction === "undo" ? undoStack : redoStack;
    const destination = direction === "undo" ? redoStack : undoStack;
    const action = source.pop();
    if (!action) {
        notify(`没有可${label}的操作。`);
        return;
    }
    useHistory.setState({ busy: true });
    sync();
    try {
        await runTask(label, () => action[direction]());
        destination.push(action);
        notify(`已${label}：${action.label}。`);
    }
    catch (error) {
        source.push(action);
        notify(`${label}失败（${action.label}）：${errorText(error)}`, "error");
    }
    finally {
        useHistory.setState({ busy: false });
        sync();
    }
}
export const undoLastAction = () => applyHistory("undo");
export const redoLastAction = () => applyHistory("redo");
export async function captureRowStates(ids) {
    return ids.length ? (await getRowsByIds([...new Set(ids)].sort((a, b) => a - b))).map(mutableRowState) : [];
}
export async function captureSelectionStates(selection) {
    return captureRowStates(await selectedRowIds(selection));
}
export async function restoreRowStates(states) {
    if (!states.length)
        return;
    await restoreMutableRowStates(states);
    await afterLibraryMutation();
}
export async function recordRowStateChange(label, before) {
    if (!before.length)
        return false;
    const after = await captureRowStates(before.map(row => row.rowId));
    if (JSON.stringify(before) === JSON.stringify(after))
        return false;
    recordHistory({ label, undo: () => restoreRowStates(before), redo: () => restoreRowStates(after) });
    return true;
}
export async function refreshTagChanges(changes) {
    const ids = new Set();
    for (const change of [...changes.added, ...changes.removed])
        for (const id of change.rowIds)
            ids.add(id);
    await afterLibraryMutation({ impact: { kind: "tags", rowIds: [...ids] } });
}
/** The committed backend delta is also the history entry: no whole-row rereads. */
export function recordTagChange(changes, label = "编辑 Tag") {
    if (!changes.added.length && !changes.removed.length)
        return false;
    const restore = async (reverse) => {
        await applyTagChanges(changes, reverse);
        await refreshTagChanges(changes);
    };
    recordHistory({ label, undo: () => restore(true), redo: () => restore(false) });
    return true;
}
