from pathlib import Path
import subprocess, time, json, ctypes, sys, shutil

lab=Path('D:/Agent/Agent_temp/memory-lab-20261029')
class Memory(ctypes.Structure):
    _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(x,ctypes.c_ulonglong) for x in ['total','available','totalPage','availablePage','totalVirtual','availableVirtual','extended']]
def available():
    m=Memory();m.length=ctypes.sizeof(m);ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));return m.available
def run(label, memory, swap, image, command, timeout=180):
    if available()<3*1024**3:raise RuntimeError('Host available memory below 3 GiB; no test started')
    name='smart-memory-lab-'+label.lower().replace('_','-')
    args=['docker','run','--name',name,'--read-only','--network','none','--memory',f'{memory}m','--memory-swap',f'{swap}m','--cpus','2','--pids-limit','128','--ulimit','core=0','--mount',f'type=bind,source={lab.as_posix()},target=/lab','-e','TMPDIR=/lab/tmp','--entrypoint',command[0],image]+command[1:]
    start=time.monotonic();minimum=available();reason=None
    with (lab/'results'/f'{label}.jsonl').open('w',encoding='utf-8') as log:
        p=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT)
        while p.poll() is None:
            minimum=min(minimum,available())
            if minimum<3*1024**3 or time.monotonic()-start>timeout:
                reason='host_memory_guard' if minimum<3*1024**3 else 'timeout'
                subprocess.run(['docker','kill',name],capture_output=True)
                break
            time.sleep(.5)
        code=p.wait(timeout=15)
    inspection=subprocess.run(['docker','inspect',name],capture_output=True,text=True,encoding='utf-8')
    details=json.loads(inspection.stdout)[0] if inspection.returncode==0 else {}
    result={'label':label,'memoryMiB':memory,'memorySwapMiB':swap,'exitCode':code,'state':details.get('State'),'hostMinAvailableMiB':minimum/1024**2,'seconds':time.monotonic()-start,'guard':reason,'command':args}
    (lab/'results'/f'{label}.summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    subprocess.run(['docker','rm',name],capture_output=True)
    print(json.dumps({k:v for k,v in result.items() if k not in ['command','state']}),flush=True)
    return result

if __name__=='__main__':
    if sys.argv[1]=='seed':
        run('seed',768,768,'rust:latest',['/lab/target/release/memory-lab','seed','/lab/fixture.sqlite'],300)
    elif sys.argv[1] in ['backend','backend-baseline']:
        cases=[('baseline',768,768)] if sys.argv[1]=='backend-baseline' else [('baseline',128,128),('file',128,128)]
        for mode,mem,swap in cases:
            for repeat in range(1,3):
                shutil.copy2(lab/'fixture.sqlite',lab/'working.sqlite')
                run(f'db_{mode}_{mem}_{swap}_r{repeat}',mem,swap,'rust:latest',['/lab/target/release/memory-lab',mode,'/lab/working.sqlite'])
    elif sys.argv[1] in ['history','history-wide']:
        cases=[('tag-only',10000,768)] if sys.argv[1]=='history-wide' else [('baseline',10000,768),('baseline',10000,256),('baseline',70000,768),('baseline',70000,256),('tag-only',10000,256),('tag-only',70000,256)]
        for mode,count,mem in cases:
            for repeat in range(1,3):
                run(f'js_{mode}_{count}_{mem}_r{repeat}',mem,mem,'vinlic/doubao-free-api:latest',['node','--max-old-space-size=640','/lab/history-bench.mjs',mode,str(count),'3'])
