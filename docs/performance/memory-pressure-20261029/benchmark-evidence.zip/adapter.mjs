export const tags = new Map();
export const create=init=>{let state=init();return {getState:()=>state,setState:patch=>Object.assign(state,patch)}};
export const useTasks={getState:()=>({busy:false})};
export const runTask=async(label,fn)=>fn();
export const notify=()=>{};
export const errorText=String;
export const registerHistoryClearer=()=>{};
export const afterLibraryMutation=async()=>{};
export const selectedRowIds=async s=>s.rowIds;
const pos='white dress, blue sky, landscape, detailed lighting, '.repeat(26);
const character='long hair, blue eyes, standing, '.repeat(10);
const negative='low quality, watermark, blurry, '.repeat(12);
export async function getRowsByIds(ids) {
  // Simulate the asynchronous IPC boundary. Database cost is measured separately.
  await new Promise(resolve=>setImmediate(resolve));
  const flat=text=>Buffer.from(text,'utf8').toString('utf8');
  const rows=ids.map(id=>process.env.LAB_VARIANT==='tag-only'?{id,tags:[...(tags.get(id)??[])]}:{
    id,positivePrompt:flat(`artist:painter${id%97}, unique${id}, ${pos}`),
    characterPrompt:flat(`character${id%31}, ${character}`),negativePrompt:flat(negative),
    note:`海边 fixture image ${id}`,artists:`painter${id%97}`,artistLlm:null,
    tags:[...(tags.get(id)??[])],groupId:null,
  });
  // Independent flat strings approximate returned rows; no synthetic IPC JSON copies.
  // Native database and actual WebView IPC are deliberately outside this experiment.
  return rows;
}
export async function restoreMutableRowStates(states) {
  for(const state of states) tags.set(state.rowId,[...state.tags]);
}
