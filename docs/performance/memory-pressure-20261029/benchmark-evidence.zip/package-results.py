from pathlib import Path
import json, sqlite3, hashlib, zipfile
lab=Path('D:/Agent/Agent_temp/memory-lab-20261029')
repo=Path('D:/Agent/智能表格')
dest=repo/'docs/performance/memory-pressure-20261029'
dest.mkdir(parents=True,exist_ok=True)
db=sqlite3.connect(f'file:{(lab/"fixture.sqlite").as_posix()}?mode=ro',uri=True)
fixture={'rows':db.execute('select count(*) from rows').fetchone()[0],
 'averageTextBytes':db.execute("select avg(length(cast(coalesce(positive_prompt,'')||coalesce(character_prompt,'')||coalesce(negative_prompt,'')||coalesce(note,'')||coalesce(artists,'')||coalesce(image_path,'') as blob))) from rows").fetchone()[0],
 'sizeBytes':(lab/'fixture.sqlite').stat().st_size,'quickCheck':db.execute('pragma quick_check').fetchone()[0]}
db.close()
runs=[]
for file in sorted((lab/'results').glob('*.summary.json')):
    summary=json.loads(file.read_text(encoding='utf-8'))
    records=[];errors=[]
    for line in (lab/'results'/(summary['label']+'.jsonl')).read_text(encoding='utf-8').splitlines():
        try:records.append(json.loads(line))
        except ValueError:
            if line.strip():errors.append(line)
    summary['measurements']=records;summary['errors']=errors
    runs.append(summary)
sources=json.loads((lab/'source-manifest.json').read_text(encoding='utf-8'))
for file in ['src/react/state/history.ts','src/lib/api/rows.ts','src-tauri/src/fsx.rs','Cargo.lock']:
    sources[file]=hashlib.sha256((repo/file).read_bytes()).hexdigest()
result={'sourceCommit':'b0a6f3bc529d46a7d4c3f1c8bf0d4cb1a965f03f','date':'2026-10-29','fixture':fixture,'sourceHashes':sources,'runs':runs,
 'excluded':['results/pilot-js: preliminary mock included extra JSON serialization; superseded by flat-string fixture','db_baseline_256_256_r1: manually stopped to narrow the matrix, no completed result','seed: preparation exceeded 300s, not a measured application failure; completed with finish-fixture.py'],
 'limits':['Linux containers, not Windows WebView2','No swap; hard memory limits do not reproduce Windows 96% memory use','Database uses Windows bind mount, timings include cross-OS filesystem overhead','History benchmark uses real history functions but synthetic returned rows; excludes actual database/IPC/UI','Tag-only prototype assumes a projected backend response; not a production implementation']}
(dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'fixture':fixture,'runs':len(runs),'hostMinMiB':min(r['hostMinAvailableMiB'] for r in runs)},ensure_ascii=False))
with zipfile.ZipFile(dest/'benchmark-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for file in lab.rglob('*'):
        relative=file.relative_to(lab)
        if not file.is_file() or any(p in ['target','vendor','cargo','crate-downloads','tmp','__pycache__'] for p in relative.parts):continue
        if file.suffix in ['.sqlite','.sqlite-wal','.sqlite-shm']:continue
        if file.name.startswith(('fixture.sqlite','working.sqlite')):continue
        archive.write(file,relative.as_posix())
