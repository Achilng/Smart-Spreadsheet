from pathlib import Path
import tomllib, tarfile, hashlib, json, urllib.request
lab=Path('D:/Agent/Agent_temp/memory-lab-20261029')
packages=tomllib.loads(Path('D:/Agent/智能表格/Cargo.lock').read_text(encoding='utf-8'))['package']
index={}
for p in packages:index.setdefault(p['name'],[]).append(p)
selected={}
def add(spec):
    parts=spec.split()
    choices=index[parts[0]]
    p=next((p for p in choices if len(parts)<2 or p['version']==parts[1]),None)
    if p is None:raise ValueError(spec)
    key=p['name']+'-'+p['version']
    if key in selected:return
    selected[key]=p
    for dep in p.get('dependencies',[]):add(dep)
for name in ['rusqlite','serde','serde_json','thiserror','regex','sha2','chrono']:add(name)
for key,p in selected.items():
    archive=Path('D:/Rust/cargo/registry/cache/index.crates.io-1949cf8c6b5b557f')/(key+'.crate')
    if not archive.exists():
        archive=lab/'crate-downloads'/(key+'.crate')
        archive.parent.mkdir(exist_ok=True)
        if not archive.exists():urllib.request.urlretrieve('https://static.crates.io/crates/'+p['name']+'/'+key+'.crate',archive)
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=p['checksum']:raise ValueError('checksum mismatch: '+key)
    with tarfile.open(archive) as tf:tf.extractall(lab/'vendor',filter='data')
    folder=lab/'vendor'/key
    files={f.relative_to(folder).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in folder.rglob('*') if f.is_file() and f.name!='.cargo-checksum.json'}
    (folder/'.cargo-checksum.json').write_text(json.dumps({'files':files,'package':p['checksum']}),encoding='utf-8')
print(json.dumps({'vendored_packages':len(selected)}))
