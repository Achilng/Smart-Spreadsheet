from pathlib import Path
import json
lab=Path('D:/Agent/Agent_temp/memory-lab-20261029')
for summary in sorted((lab/'results').glob('*.summary.json')):
    s=json.loads(summary.read_text(encoding='utf-8'))
    records=[]
    for line in summary.with_name(s['label']+'.jsonl').read_text(encoding='utf-8').splitlines():
        try:records.append(json.loads(line))
        except ValueError:pass
    print(s['label'],'exit',s['exitCode'],'oom',s.get('state',{}).get('OOMKilled'),'guard',s.get('guard'))
    for r in records:
        if 'memory' in r:
            print(' ',r['stage'],r.get('round',''),round(r['ms'],1),'ms rss',round(r['memory']['rss']/1024**2,1),'MiB peak',round(r['maxRssKiB']/1024,1),'lag',round(r['eventLoopMaxMs'],1))
        else:
            print(' ',r['stage'],round(r['ms'],1),'ms',r['rss'],r['hwm'],r['detail'])
