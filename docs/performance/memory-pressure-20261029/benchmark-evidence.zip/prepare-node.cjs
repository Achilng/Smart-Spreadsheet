const fs=require('node:fs');
const ts=require('D:/Agent/智能表格/node_modules/typescript');
const lab='D:/Agent/Agent_temp/memory-lab-20261029';
const root='D:/Agent/智能表格';
let history=fs.readFileSync(root+'/src/react/state/history.ts','utf8').replace(/^import .*;\r?\n/gm,'');
const rows=fs.readFileSync(root+'/src/lib/api/rows.ts','utf8');
const mutable=rows.slice(rows.indexOf('export function mutableRowState('), rows.indexOf('export interface RowPage'));
const prefix=`import {create,getRowsByIds,restoreMutableRowStates,selectedRowIds,afterLibraryMutation,notify,runTask,useTasks,errorText,registerHistoryClearer} from './adapter.mjs';\n`;
for(const mode of ['baseline','tag-only']) {
  const source=prefix+mutable+history.replace('.map(mutableRowState)',mode==='baseline'?'.map(mutableRowState)':'.map(row => ({rowId:row.id,tags:[...row.tags]}))');
  fs.writeFileSync(lab+'/history-'+mode+'.mjs',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText);
}
