from pathlib import Path
import sqlite3,json
path=Path('D:/Agent/Agent_temp/memory-lab-20261029/fixture.sqlite')
db=sqlite3.connect(path)
keys=dict(db.execute('select distinct artists,artist_match_key from rows'))
db.create_function('style_match_key',2,lambda artist,settings:keys.get(artist),deterministic=True)
count=db.execute('select count(*) from rows').fetchone()[0]
print('existing rows',count)
db.row_factory=sqlite3.Row
sample=dict(db.execute('select * from rows limit 1').fetchone())
columns=[key for key in sample if key!='id']
statement='insert into rows('+','.join(columns)+') values ('+','.join('?' for _ in columns)+')'
print('columns',columns)
for i in range(count+1,70001):
    row=sample.copy()
    row.update(source_ordinal=i,identity=f'fixture-{i}',positive_prompt=f'artist:painter{i%97}, unique{i}, '+('white dress, blue sky, landscape, detailed lighting, '*26),character_prompt=f'character{i%31}, '+('long hair, blue eyes, standing, '*10),negative_prompt='low quality, watermark, blurry, '*12,note=f'海边 fixture image {i}',artists=f'painter{i%97}',time=f'2026-01-{i%28+1:02d}T00:00:00Z',image_path=f'/synthetic/image-{i}.png',style_signature=None)
    db.execute(statement,[row[key] for key in columns])
db.commit()
print('final count',db.execute('select count(*) from rows').fetchone()[0])
print('integrity',db.execute('pragma quick_check').fetchone()[0])
db.execute('pragma wal_checkpoint(truncate)')
db.close()
