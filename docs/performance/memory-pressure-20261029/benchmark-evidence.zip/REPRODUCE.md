# Isolated memory experiment — 2026-10-29

This evidence bundle is an experimental harness, not a production feature or unit-test suite.
All paths intentionally default to D:/Agent/Agent_temp/memory-lab-20261029. No real library or images are used.

## Environment

- Windows host, Docker Desktop already running, Linux/WSL2 cgroup v1.
- Existing images rust:latest (rustc 1.96.0) and vinlic/doubao-free-api:latest (Node v22.12.0), with entrypoint overridden.
- No images pulled, no installed environment components upgraded.
- Containers: read-only root, no network, 2 CPUs, 128 PIDs, core dumps disabled.
- Tests: 128/256/768 MiB, memory-swap equals memory (no swap). Build: 1 GiB, 2 jobs.
- One container at a time. Host guard stops/declines tests below 3 GiB available physical memory.

## Evidence and implementation

`backend/src` contains the actual database and required helper sources copied at the recorded hashes. Only an additional `Database::lab_temp_file` helper changes the experimental mode. The baseline database methods are unchanged. Unrelated application/UI modules are not linked.

`history-baseline.mjs` is transpiled from actual history.ts and mutableRowState. Imports are replaced by the controlled adapter. Fresh independent flat strings model returned records. There is no synthetic JSON serialize/parse in the final adapter; actual `recordRowStateChange` still calls JSON.stringify. Real IPC/native database cost is excluded.

`history-tag-only.mjs` changes snapshot projection to row ID plus tags and the adapter models a tag-only response. This is a hypothesis prototype; it does not implement a production backend API, cross-window consistency or transactional tag-only undo.

Preliminary results under `results/pilot-js/` deliberately remain in the evidence but are excluded from conclusions because the preliminary adapter introduced extra JSON copies. The abandoned 256 MiB backend run is also excluded. Seed timeout is preparation failure, not an application OOM.

## Re-run

Extract into the original D: temporary directory. Baseline copied Rust sources are included, so they do not need to be reconstructed from a changed checkout. Reuse the bundled Cargo.lock and existing versions; `vendor.py` can populate vendor dependencies from the existing D:/Rust cache and download missing exact archives with lockfile checksum verification. Do not run it if that path is inappropriate.

Build (PowerShell, existing Docker images only):

```powershell
New-Item -ItemType Directory -Force D:/Agent/Agent_temp/memory-lab-20261029/tmp,D:/Agent/Agent_temp/memory-lab-20261029/results
docker run --rm --name smart-memory-lab-build --read-only --network none --memory 1g --memory-swap 1g --cpus 2 --pids-limit 128 --mount 'type=bind,source=D:/Agent/Agent_temp/memory-lab-20261029,target=/lab' --mount 'type=bind,source=D:/Agent/Agent_temp/memory-lab-20261029/vendor,target=/registry,readonly' -e CARGO_HOME=/lab/cargo -e CARGO_TARGET_DIR=/lab/target -e TMPDIR=/lab/tmp -e CARGO_BUILD_JOBS=2 -w /lab/backend rust:latest cargo build --release --offline
```

Data preparation: `python run-lab.py seed`, then `python finish-fixture.py`. During this run, slow bind-mount writes led the first command to time out after 38,500 rows. The second script deterministically completed the fixture to 70,000 rows and checked SQLite integrity. It reuses existing artist-key mappings and sets unused style signatures to NULL for added rows. These fields are not query predicates in this experiment. Do not repeatedly run `seed` on an existing fixture.

Run `python run-lab.py history`, `python run-lab.py history-wide`, `python run-lab.py backend-baseline`, `python run-lab.py backend`. The last command intentionally includes the failed FILE prototype to preserve the experiment. Inspect summary `guard`, `State.OOMKilled`, exit status and final stage together: exit 137 alone does not establish an OOM.

All samples use new sequential containers; database runs start from a fresh fixture copy. Repeated hard-kill runs may leave SQLite working-file sidecars; ensure a clean test working database before any unrelated follow-up measurement. Never point the harness at a real library.

## Interpretation

The 128 MiB baseline stalled at first search until the 180s timeout; it was not OOM-killed. The FILE prototype failed with SQLite extended code 1546 (SQLITE_IOERR_TRUNCATE) on this filesystem and is not evidence that disk-backed search is effective or ineffective on native Windows.

RSS includes shared pages and can exceed cgroup charges. Compare reported process peak RSS only with the same process metric; determine enforcement from Docker's OOM state/cgroup limit. Node was given --max-old-space-size=640 consistently, so these are controlled hard-limit experiments rather than default Node/WebView2 heap-policy measurements.

Do not equate measured operation times with a user's Windows desktop latency. This experiment excludes original-image decoding, rendering, GPU memory, other windows, and operating-system paging.
