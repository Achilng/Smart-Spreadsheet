#![allow(dead_code, unused_imports)]
mod db;
mod automation;
mod pipeline;
mod storage;
mod fsx;
use db::*;
use std::{time::Instant, io::Write};
use serde_json::json;

fn emit(stage: &str, start: Instant, detail: serde_json::Value) {
    let status = std::fs::read_to_string("/proc/self/status").unwrap_or_default();
    let rss = status.lines().find(|s| s.starts_with("VmRSS:")).unwrap_or("").to_owned();
    let hwm = status.lines().find(|s| s.starts_with("VmHWM:")).unwrap_or("").to_owned();
    let cg = |file: &str| std::fs::read_to_string(format!("/sys/fs/cgroup/memory/{file}")).unwrap_or_default();
    println!("{}", json!({"stage":stage,"ms":start.elapsed().as_secs_f64()*1000.0,"rss":rss,"hwm":hwm,"detail":detail,"cgroup_usage":cg("memory.usage_in_bytes"),"cgroup_max":cg("memory.max_usage_in_bytes"),"cgroup_stat":cg("memory.stat")}));
    std::io::stdout().flush().unwrap();
}
fn query(search: &str) -> RowQuery {
    serde_json::from_value(json!({"offset":0,"limit":200,"tags":[],"tagMode":"and","dedupe":"none","search":search})).unwrap()
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<String> = std::env::args().collect();
    let mode = &args[1];
    let path = &args[2];
    let t = Instant::now();
    let mut db = Database::open(path)?;
    emit("open", t, json!({"mode":mode}));
    if mode == "seed" {
        let t = Instant::now();
        for chunk in 0..140 {
            let rows: Vec<_> = (1..=500).map(|n| {
                let i = chunk*500+n;
                NewRow {source_ordinal:i, identity:format!("fixture-{i}"),
                    positive_prompt:Some(format!("artist:painter{}, unique{}, {}",i%97,i,"white dress, blue sky, landscape, detailed lighting, ".repeat(26))),
                    character_prompt:Some(format!("character{}, {}",i%31,"long hair, blue eyes, standing, ".repeat(10))),
                    negative_prompt:Some("low quality, watermark, blurry, ".repeat(12)),
                    note:Some(format!("海边 fixture image {i}")),artists:Some(format!("painter{}",i%97)),
                    time:Some(format!("2026-01-{:02}T00:00:00Z",i%28+1)),image_path:Some(format!("/synthetic/image-{i}.png")),..Default::default()}
            }).collect();
            db.append_batch(SourceType::Folder,"/synthetic",&rows, |_|Ok(()))?;
        }
        emit("seed",t,json!({"rows":70000,"images":"none"}));
        return Ok(());
    }
    if mode == "file" { db.lab_temp_file()?; }
    let t = Instant::now(); let page = db.query_rows(&query(""))?;
    emit("list",t,json!({"count":page.total_count})); drop(page);
    for (stage, text) in [("search_first","painter42"),("search_miss","notfoundneedle"),("search_common","white dress"),("search_repeat","painter42")] {
        let t = Instant::now(); let page = db.query_rows(&query(text))?;
        emit(stage,t,json!({"count":page.total_count}));
    }
    let t=Instant::now();db.update_note(1,"changed 海边")?;db.bump_data_version();
    emit("note_write",t,json!({}));
    let t=Instant::now();let tags=db.list_tags()?;let page=db.query_rows(&query("painter42"))?;let detail=db.get_rows_by_ids(&[1])?;
    emit("note_refresh",t,json!({"count":page.total_count,"tags":tags.len(),"detail":detail.len()}));drop(page);drop(detail);
    let t=Instant::now();let result=db.add_tags_to_selection(&RowSelection::Explicit{row_ids:(1..=10000).collect()}, &["lab-tag".to_owned()])?;db.bump_data_version();
    emit("tags_write_10000",t,json!({"changed":result.associations_changed}));
    let t=Instant::now();let tags=db.list_tags()?;let page=db.query_rows(&query("painter42"))?;
    emit("tags_refresh",t,json!({"count":page.total_count,"tags":tags.len()}));
    Ok(())
}
