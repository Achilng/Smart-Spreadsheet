from pathlib import Path
import shutil, json, hashlib

root = Path('D:/Agent/智能表格')
lab = Path('D:/Agent/Agent_temp/memory-lab-20261029')
src = lab / 'backend/src'
src.mkdir(parents=True, exist_ok=True)
manifest = {}
def copy(relative, target):
    source = root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    manifest[relative] = hashlib.sha256(source.read_bytes()).hexdigest()
for folder in ['db', 'automation']:
    for file in (root / 'src-tauri/src' / folder).rglob('*.rs'):
        copy(file.relative_to(root).as_posix(), src / file.relative_to(root / 'src-tauri/src'))
for file in ['artist.rs','prompt_text.rs','style_signature.rs']:
    copy('src-tauri/src/pipeline/' + file, src / 'pipeline' / file)
copy('src-tauri/src/storage/rule_files.rs', src / 'storage/rule_files.rs')
copy('src-tauri/src/fsx.rs', src / 'fsx.rs')
with (src/'db/mod.rs').open('a',encoding='utf-8') as out:
    out.write('\nimpl Database { pub fn lab_temp_file(&mut self) -> Result<(), DatabaseError> { self.connection.execute_batch("PRAGMA temp_store = FILE;")?; Ok(()) } }\n')
(src / 'pipeline/mod.rs').write_text('mod artist; pub mod prompt_text; pub mod style_signature; pub use artist::{artist_string,extract_artist_blocks,extract_artist_tags}; pub(crate) use artist::llm_artist_pool_fragments; pub use style_signature::{STYLE_SIGNATURE_VERSION,style_signature_of};', encoding='utf-8')
(src / 'storage/mod.rs').write_text('pub mod rule_files;', encoding='utf-8')
(lab / 'backend/Cargo.toml').write_text('''[package]
name = "memory-lab"
version = "0.1.0"
edition = "2024"
[dependencies]
rusqlite = { version = "=0.39.0", default-features = false, features = ["backup", "bundled", "functions"] }
serde = { version = "1.0.228", features = ["derive"] }
serde_json = { version = "1.0.150", features = ["preserve_order"] }
thiserror = "2.0.18"
regex = "1.12"
sha2 = "0.10.9"
chrono = { version = "0.4.44", default-features = false, features = ["clock"] }
[profile.release]
opt-level = 2
debug = false
''', encoding='utf-8')
config = lab / 'backend/.cargo/config.toml'
config.parent.mkdir(parents=True, exist_ok=True)
config.write_text('''[source.crates-io]
replace-with = "local-cache"
[source.local-cache]
directory = "/registry"
''', encoding='utf-8')
(lab / 'source-manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
